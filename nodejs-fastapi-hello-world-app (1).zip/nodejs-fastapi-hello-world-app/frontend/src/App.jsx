import React, { useEffect } from "react";
import { HashRouter as Router, Routes, Route } from "react-router-dom";

import Layout from "./components/Layout";
import Login from "./components/Login";
import HomePage from "./pages/HomePage";
import { useAppContext } from "./context/AppContext";
import Header from "./components/Header";
import AuthCallback from "./components/AuthCallback";
import DataProducts from "./components/DataProducts";
import ServiceNowComponent from "./components/ServiceNowComponent";

function App() {
  const {formData, setFormData, setUser} = useAppContext()
  //  const { isLogin } = useAppContext();

  useEffect(() => {
    fetch("https://frontend-shell-547392274449981.1.azure.databricksapps.com/api/token")
      .then((res) => {
        const gapAuth = res.headers.get("gap-auth");
        console.log("gap-auth header:", gapAuth);

        if (gapAuth) {
          const email = gapAuth || "";

          // Extract name from before @
          const rawName = email.split("@")[0] || "";

          // Format name nicely
          const formattedName = rawName
            .split(".")                      // devendra.khinchi -> ["devendra", "khinchi"]
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1)) // capitalize
            .join(" ");                      // join with space
          console.log(formattedName, email);
          setUser({ name: formattedName, email });
          setFormData({
            name: formattedName,
            email,
            department: "",
            duration: "",
            purpose: "",
            justification: "",
          })
        }

        return res.json();
      })
      .then((body) => console.log("Response Body:", body))
      .catch((err) => console.log("Error in API call:", err));
  }, []);

  return (
    <Router>
      <Routes>
        {/* Login page WITHOUT layout */}

        {/* All other pages WITH layout */}
        <Route
          path="/xyz"
          element={
            <Layout
              showChatbot={false}
              header={
                <div className="flex items-center w-full">
                  <Header isLogin={false} />
                </div>
              }
            >
              <Login />
              {/* <DatabricksLogin/> */}
            </Layout>
          }
        />
        {/* <Route path="/auth/callback" element={<AuthCallback />} /> */}
        <Route
          path="/"
          element={
            <Layout
              showChatbot={true}
              header={
                <div className="flex items-center w-full">
                  <Header isLogin={true} />
                </div>
              }
            >
              <HomePage />
            </Layout>
          }
        />

        <Route
          path="/dataProduct"
          element={
            <Layout
              showChatbot={true}
              header={
                <div className="flex items-center w-full">
                  <Header isLogin={true} />
                </div>
              }
            >
              <DataProducts />
            </Layout>
          }
        />

        <Route path="/servicenow" element={<ServiceNowComponent formData={formData}/>} />
      </Routes>
    </Router>
  );
}

export default App;
