import React from "react";
import { DollarSign, BarChart2, ShieldCheck, PieChart } from "lucide-react";
import icon from '../assets/icons/homeIcon.svg'

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center text-center">
      
      {/* Top Icon Circle */}
      <div className="w-20 h-20 rounded-full bg-linear-to-r from-[#FFF4D1] to-[#FECDCA] flex items-center justify-center mb-6">
        <img 
          src={icon}
          alt={icon}
          className="w-10 h-10"
        />
      </div>

      {/* Title */}
      <h2 className="text-2xl text-[#2F3A55] mb-3">
        Start Your Data Discovery
      </h2>

      {/* Subtitle */}
      <p className="text-gray-500 text-sm max-w-sm leading-small mb-8">
        Ask questions about data products and discover insights instantly. 
        Try exploring costs, performance metrics, or IT4IT domain KPIs relevant to your work.
      </p>

      {/* Buttons */}
      <div className="grid grid-cols-2 gap-x-4 gap-y-4">
      
        {/* Infrastructure Costs */}
        <button className="flex items-center gap-2 px-4 py-2 bg-[#EFF6FF] rounded-lg text-[#1447E6] text-sm">
          💰 Infrastructure costs
        </button>

        {/* Financial Reports */}
        <button className="flex items-center gap-2 px-4 py-2 bg-[#F0FDF4] text-[#008236] rounded-lg text-sm">
          📈 Financial reports
        </button>

        {/* Production Metrics */}
        <button className="flex items-center gap-2 px-4 py-2 bg-[#FAF5FF] text-[#8200DB] rounded-lg text-sm">
          📊 Production metrics
        </button>

        {/* HSE Compliance */}
        <button className="flex items-center gap-2 px-4 py-2 bg-[#FFF7ED] text-[#CA3500] rounded-lg text-sm">
          🛡️ HSE compliance
        </button>
      </div>
    </div>
  );
}
