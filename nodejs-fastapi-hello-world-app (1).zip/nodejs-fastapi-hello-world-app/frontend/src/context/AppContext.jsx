import React, { createContext, useContext, useEffect, useState } from "react";

// Create Context
const AppContext = createContext();

// Provider Component
export function AppProvider({ children }) {
  // Global States here
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showChatbot, setShowChatbot] = useState(false);
  const [user, setUser] = useState(null);
  const [pageTitle, setPageTitle] = useState(
    "IT4IT Data Product Lakehouse Portal"
  );
  const [showRightHeader, setShowRightHeader] = useState(true);

  const [messages, setMessages] = useState(
    JSON.parse(sessionStorage.getItem("messages")) || [
      {
        id: 1,
        text: "Hi there! I can help you discover governed data products across IT4IT domains.",
        sender: "bot",
        timestamp: new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
        }),
      },
    ]
  );

  const [productPermission, setProductPermission] = useState(null);
  const [dataQualityModalVisible, setDataQualityModalVisible] = useState(null);
  const [finalProducts, setFinalProducts] = useState(
    JSON.parse(sessionStorage.getItem("finalProducts")) || []
  );
  const [formData, setFormData] = useState({
    name: "Shruti Bhimrajka",
    email: "shruti.bhimrajka1@celebaltech.com",
    department: "",
    duration: "",
    purpose: "",
    justification: "",
  });

  // Login Function
  const login = (userData) => {
    setUser(userData);
    setIsLoggedIn(true);
    setShowRightHeader(true);
  };

  // Logout Function
  const logout = () => {
    setUser(null);
    setIsLoggedIn(false);
    setShowRightHeader(false);
  };

  // update final products and messages in session storage
  useEffect(() => {
    sessionStorage.setItem("finalProducts", JSON.stringify(finalProducts));
  }, [finalProducts]);
  useEffect(() => {
    sessionStorage.setItem("messages", JSON.stringify(messages));
  }, [messages]);
  return (
    <AppContext.Provider
      value={{
        isLoggedIn,
        setIsLoggedIn,
        user,
        setUser,
        login,
        logout,
        pageTitle,
        setPageTitle,
        showRightHeader,
        setShowRightHeader,
        showChatbot,
        setShowChatbot,
        productPermission,
        setProductPermission,
        finalProducts,
        setFinalProducts,
        formData,
        setFormData,
        messages,
        setMessages,
        dataQualityModalVisible,
        setDataQualityModalVisible,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

// Custom hook for easy usage
export const useAppContext = () => useContext(AppContext);
