import React, {useState} from "react";
import { User, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAppContext } from "../context/AppContext";

function Login() {

  const navigate = useNavigate()

  const { login } = useAppContext();

  const [userEmail, setUserEmail] = useState('')
  const [userPassword, setUserPassword] = useState('')

  const handlelogin = () => {
    const email = "shruti@gmail.com"
    const password = "shruti1234"

    if(userEmail == email && userPassword == password){
      navigate('/home')
      alert('Login Successful!')
    }
    else {
      alert('Credentials Invalid')
    }


  }

  return (
    <div className="flex items-center justify-center">
      <div className="flex flex-col gap-1  bg-white w-full max-w-md rounded-2xl shadow-xl p-8">
        
        {/* Heading */}
        <h2 className="text-xl text-center">
          Welcome to EDP Data Product Portal
        </h2>
        <p className="text-gray-500 text-center mt-1">
          Sign in to access your data products
        </p>

        {/* Username */}
        <div className="mt-4">
          <label className="text-sm font-medium text-gray-700">Username</label>
          <div className="mt-1 relative">
            <User className="absolute left-3 top-3 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Enter your username"
              value={userEmail}
               onChange={(e)=>setUserEmail(e.target.value)}
              className="w-full border rounded-md pl-10 pr-3 py-2 bg-[#F3F3F5] border-[#D1D5DC] focus:outline-blue-500"
            />
          </div>
        </div>

        {/* Password */}
        <div className="mt-4">
          <label className="text-sm font-medium text-gray-700">Password</label>
          <div className="mt-1 relative">
            <Lock className="absolute left-3 top-3 text-gray-400 h-5 w-5" />
            <input
              type="password"
              value={userPassword}
              onChange={(e)=>setUserPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full border rounded-md pl-10 pr-3 py-2 bg-[#F3F3F5] border-[#D1D5DC] focus:outline-blue-500"
            />
          </div>
        </div>

        {/* Sign In Button */}
        <button onClick={handlelogin} className="w-full bg-[#F7D117] font-medium py-2 rounded-md mt-6">
          Sign In
        </button>

        {/* Forgot Password */}
        <div className="text-center mt-3">
          <a href="#" className="text-blue-600 text-sm hover:underline">
            Forgot your password?
          </a>
        </div>

        {/* Footer Text */}
        <div className="border-t border-[#E5E7EB] mt-6 pt-4">
          <p className="text-center text-gray-500 text-xs">
            Powered by AI-driven data discovery
          </p>
        </div>

      </div>
    </div>
  );
}

export default Login;
