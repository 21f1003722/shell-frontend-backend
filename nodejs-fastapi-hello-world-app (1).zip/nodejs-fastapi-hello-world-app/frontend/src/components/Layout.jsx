import React from "react";
import Sidebar from "./Sidebar";
import Chatbot from "./Chatbot";
import ProductModal from "./modals/ProductModal";
import { useAppContext } from "../context/AppContext";
import DataQualityInfoModal from "./modals/DataQualityInfoModal";

export default function Layout({ children, header, showChatbot = false }) {
  const { productPermission, dataQualityModalVisible } = useAppContext();

  return (
    <div className={`flex ${showChatbot ? "items-center" : "flex-col"} w-full`}>
      {/* Left Section (Main Layout) */}
      <div
        className={`h-screen bg-gray-50 flex flex-col overflow-hidden 
        ${showChatbot ? "w-[75%]" : "w-full"}`}
      >
        <div className="relative">
          {/* Header */}
          <header className="h-[76px] flex items-center bg-white shadow-sm p-4 text-xl font-semibold sticky top-0 z-20">
            {header || "Header"}
          </header>

          {/* Body (Sidebar + Content) */}
          <div className="flex w-full" style={{ height: "calc(100vh - 76px)" }}>
            {/* Sidebar */}
            <aside className="w-[164px] border-r shadow-sm bg-white">
              <Sidebar />
            </aside>

            {/* Content Area */}
            <main className="flex-1 p-6 overflow-auto">
              <div className="flex items-center justify-center w-full h-full">
                {children}
              </div>
            </main>
          </div>
        </div>

        {productPermission && (
          <div
            className="fixed top-0 left-0 w-[100%] z-[990] 
                  flex items-center justify-center h-full
                  backdrop-blur-sm bg-black/30"
          >
            <div className="max-h-[90vh] overflow-y-auto p-4 w-full flex items-start justify-center">
              <ProductModal />
            </div>
          </div>
        )}
        {dataQualityModalVisible && (
          <div
            className="fixed top-0 left-0 w-[100%] z-[990] 
                  flex items-center justify-center h-full
                  backdrop-blur-sm bg-black/30"
          >
            <div className="max-h-[90vh] overflow-y-auto p-4 w-full flex items-start justify-center">
              <DataQualityInfoModal />
            </div>
          </div>
        )}
      </div>

      {/* Right Section: Chatbot (Only If Enabled) */}
      {showChatbot && (
        <div className="w-[25%] h-screen sticky top-0">
          <Chatbot />
        </div>
      )}
    </div>
  );
}

// import React from "react";
// import Sidebar from "./Sidebar";

// export default function Layout({ children, header }) {
//   return (
//     <div className="min-h-screen w-full bg-gray-50 flex flex-col overflow-hidden">
//       {/* Header full width */}
//       <header className="w-full h-[76px] flex items-center bg-white shadow-md p-4 text-xl font-semibold sticky top-0 z-20">
//         {header || "Header"}
//       </header>

//       {/* Body: height = screen - header */}
//       <div
//         className="flex w-full"
//         style={{
//           height: "calc(100vh - 76px)",
//         }}
//       >
//         {/* Sidebar */}
//         <aside className="w-[164px] border-r shadow-sm bg-white ">
//           <Sidebar />
//         </aside>

//         {/* Content scrolls */}
//         <main className="flex-1 p-6 overflow-auto">
//           <div className="flex items-center justify-center w-full h-full">
//             {children}
//           </div>
//         </main>
//       </div>
//     </div>
//   );
// }
