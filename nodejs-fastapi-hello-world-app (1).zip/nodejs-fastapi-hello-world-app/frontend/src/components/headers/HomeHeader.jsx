import React from "react";
import it4 from "../../assets/icons/it4.svg";
import it4it from "../../assets/icons/it4it.svg";
import user from "../../assets/icons/user.svg";

function HomeHeader() {
  return (
    <div className="flex items-center justify-between w-full">
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-3">
          <img className="border-r pr-[12px] border-[#D1D5DC]" src={it4} alt="" />
          <img src={it4it} alt="" />
        </div>
        <div>
          <p>Data Discovery Assistant</p>
          <p className="text-sm font-medium text-[#6A7282]">
          Ask questions in natural language to find data products
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <div>
          <img className="rounded-full" src={user} alt="" />
        </div>
        <div className="leading-tight">
          <p className="text-[14px] font-medium leading-tight">Emma Johnson</p>
          <p className="text-[14px] text-[#6A7282] font-normal leading-tight">
            Data Consumer
          </p>
        </div>
      </div>
    </div>
  );
}

export default HomeHeader;
