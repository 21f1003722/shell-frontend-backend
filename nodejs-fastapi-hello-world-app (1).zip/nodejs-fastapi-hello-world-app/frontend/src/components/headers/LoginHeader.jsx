import React from "react";
import it4 from "../../assets/icons/it4.svg";
import it4it from "../../assets/icons/it4it.svg";
import user from "../../assets/icons/user.svg";

function LoginHeader() {
  return (
    <div className="flex items-center justify-between w-full">
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-3">
          <img className="border-r pr-[12px] border-[#D1D5DC]" src={it4} alt="" />
          <img src={it4it} alt="" />
        </div>
        <div>
          <p>IT4IT Data Product Lakehouse Portal</p>
          <p className="text-sm font-medium text-[#6A7282]">
            Your intelligent data discovery platform
          </p>
        </div>
      </div>

      {/* <div className="flex items-center gap-1">
        <div>
          <img className="rounded-full" src={user} alt="" />
        </div>
        <div className="leading-tight">
          <p className="text-lg font-medium leading-tight">Emma Johnson</p>
          <p className="text-lg text-[#6A7282] font-normal leading-tight">
            Data Consumer
          </p>
        </div>
      </div> */}
    </div>
  );
}

export default LoginHeader;
