import React from "react";

function DatabricksLogin() {
const CLIENT_ID = "b525d9ab-c9c6-4c83-b343-7a953e985ad5";
const REDIRECT_URI = "http://localhost:5173/home";

const AUTH_URL =
"https://devshellbackend-547392274449981.1.azure.databricksapps.com/oidc/authorize?client_id=b525d9ab-c9c6-4c83-b343-7a953e985ad5&response_type=code&redirect_uri=http://localhost:5173/auth/callback&scope=offline_access"

  const handleLogin = () => {
    window.open(
      AUTH_URL,
      "databricksLogin",
      "width=600,height=700,top=100,left=400"
    );
  };

  console.log("FINAL URL →", AUTH_URL);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-6">
      <div className="bg-white/10 backdrop-blur-lg border border-white/20 shadow-xl rounded-3xl p-10 w-full max-w-md text-center">
        <h1 className="text-3xl font-bold text-white mb-3">Welcome</h1>
        <p className="text-gray-300 mb-10">Sign in to access Databricks Jobs</p>

        <button
          onClick={handleLogin}
          className="w-full py-3 rounded-xl font-semibold text-white 
                     bg-red-600 hover:bg-red-700 transition-all duration-300 
                     shadow-md hover:shadow-xl"
        >
          Login with Databricks
        </button>

        <p className="text-sm text-gray-400 mt-6">
          Secure OAuth 2.0 Authentication
        </p>
      </div>
    </div>
  );
}

export default DatabricksLogin;

// import React from "react";

// function DatabricksLogin() {
//   const CLIENT_ID = "YOUR_CLIENT_ID";
//   const REDIRECT_URI = "http://localhost:3000/auth/callback";

//   const DATABRICKS_AUTH_URL = `https://adb-547392274449981.1.azuredatabricks.net/oidc/authorize?client_id=2720738d-7f4e-4044-ab17-3a81fb4fbc0d&response_type=code&redirect_uri=http://localhost:5173/home&scope=offline_access`;

//   const handleLogin = () => {
//     // window.location.href = authorizeUrl;
//     window.open(
//       DATABRICKS_AUTH_URL,
//       "databricksLogin",
//       "width=600,height=700,top=100,left=400"
//     );
//   };

//   return (
//     <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-6">
//       {/* Card */}
//       <div className="bg-white/10 backdrop-blur-lg border border-white/20 shadow-xl rounded-3xl p-10 w-full max-w-md text-center">
//         <h1 className="text-3xl font-bold text-white mb-3">Welcome</h1>
//         <p className="text-gray-300 mb-10">Sign in to access Databricks Jobs</p>

//         {/* Login Button */}
//         <button
//           onClick={handleLogin}
//           className="w-full py-3 rounded-xl font-semibold text-white
//                      bg-red-600 hover:bg-red-700 transition-all duration-300
//                      shadow-md hover:shadow-xl"
//         >
//           Login with Databricks
//         </button>

//         {/* Footer */}
//         <p className="text-sm text-gray-400 mt-6">
//           Secure OAuth 2.0 Authentication
//         </p>
//       </div>
//     </div>
//   );
// }

// export default DatabricksLogin;
