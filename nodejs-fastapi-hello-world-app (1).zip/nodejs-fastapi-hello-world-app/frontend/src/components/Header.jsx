import React, {useEffect} from "react";
import it4 from "../assets/icons/it4.png";
import it4it from "../assets/icons/it4it.svg";
import userImg from "../assets/icons/user.svg";
import {useAppContext} from "../context/AppContext";
import { useNavigate } from "react-router-dom";

function Header({ isLogin = false }) {
  const { user } = useAppContext();
  const navigate = useNavigate()

  useEffect(() => {
    console.log(user,"user");
  },[user])
  return (
    <div className="flex items-center justify-between w-full">
      {/* Left Section */}
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-3">
          <img className="border-r pr-3 border-[#D1D5DC]" src={it4} alt="" />
          <img onClick={()=> navigate('/')} src={it4it} alt="" />
        </div>

        {/* Dynamic Title & Subtitle */}
        <div>
          {!isLogin ? (
            <>
              <p>IT4IT Data Product Lakehouse Portal</p>
              <p className="text-sm font-medium text-[#6A7282]">
                Your intelligent data discovery platform
              </p>
            </>
          ) : (
            <>
              <p>Data Discovery Assistant</p>
              <p className="text-sm font-medium text-[#6A7282]">
                Ask questions in natural language to find data products
              </p>
            </>
          )}
        </div>
      </div>

      {/* Right Section (Only for Home Screen) */}
      {isLogin && (
        <div className="flex items-center gap-1">
          <div>
            <img className="rounded-full" src={userImg} alt="" />
          </div>
          <div className="leading-tight">
            <p className="text-[14px] font-medium leading-tight">{user?.name || "Shruti Bhimrajka"}</p>
            <p className="text-[14px] text-[#6A7282] font-normal leading-tight">
              {user?.email || "shruti.bhimrajka1@celebaltech.com"}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default Header;
