import React from "react";
import { TrendingUp, Database, BarChart3, X } from "lucide-react";
import { useAppContext } from "../../context/AppContext";
import { Tooltip } from "react-tooltip";
import "react-tooltip/dist/react-tooltip.css";

function DataQualityInfoModal() {
  const { setDataQualityModalVisible, dataQualityModalVisible } =
    useAppContext();
  //   const [images, setImages] = useState([])

  // const imageAPI = async () => {
  //   const url = `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=${distinctness}`;
  //   const response = await fetch();
  //   const result = await response.json()
  //   console.log('gshfhsgfhgsahgfhaghfgahgfhaghfghaghfagj', result.data)
  //   setImages(result.data)

  // };

  const metrics = [
    {
      label: "Completeness",
      value: 94,
      color: "orange",
      image: `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=completeness`
      // image: `https://shellrawdata.blob.core.windows.net/shell-dev-container/__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/shell_dev_uc_shell_datasource_25_${dataQualityModalVisible.title}_completeness.png?sp=r&st=2025-12-01T05:30:50Z&se=2026-12-01T13:45:50Z&spr=https&sv=2024-11-04&sr=c&sig=N%2BvATuEOOh1ON0Lgy5PmCupKCOrwdy2hRNrMqUhog%2BM%3D`,
    },
    {
      label: "Timeliness",
      value: 95,
      color: "cyan",
      image: `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=refresh_rate`

      // image: `https://shellrawdata.blob.core.windows.net/shell-dev-container/__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/shell_dev_uc_shell_datasource_25_${dataQualityModalVisible.title}_refresh_rate.png?sp=r&st=2025-12-01T05:30:50Z&se=2026-12-01T13:45:50Z&spr=https&sv=2024-11-04&sr=c&sig=N%2BvATuEOOh1ON0Lgy5PmCupKCOrwdy2hRNrMqUhog%2BM%3D`,
    },
    {
      label: "Validity",
      value: 96,
      color: "red",
      image: `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=missingness_pct`

      // image: `https://shellrawdata.blob.core.windows.net/shell-dev-container/__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/shell_dev_uc_shell_datasource_25_${dataQualityModalVisible.title}_missingness_pct.png?sp=r&st=2025-12-01T05:30:50Z&se=2026-12-01T13:45:50Z&spr=https&sv=2024-11-04&sr=c&sig=N%2BvATuEOOh1ON0Lgy5PmCupKCOrwdy2hRNrMqUhog%2BM%3D`,
    },
    {
      label: "Accuracy",
      value: 90,
      color: "orange",
      image: `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=entropy`

      // image: `https://shellrawdata.blob.core.windows.net/shell-dev-container/__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/shell_dev_uc_shell_datasource_25_${dataQualityModalVisible.title}_entropy.png?sp=r&st=2025-12-01T05:30:50Z&se=2026-12-01T13:45:50Z&spr=https&sv=2024-11-04&sr=c&sig=N%2BvATuEOOh1ON0Lgy5PmCupKCOrwdy2hRNrMqUhog%2BM%3D`,
    },
    {
      label: "Consistency",
      value: 88,
      color: "cyan",
      image: `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=distinctness`

      // image: `https://shellrawdata.blob.core.windows.net/shell-dev-container/__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/shell_dev_uc_shell_datasource_25_${dataQualityModalVisible.title}_distinctness.png?sp=r&st=2025-12-01T05:30:50Z&se=2026-12-01T13:45:50Z&spr=https&sv=2024-11-04&sr=c&sig=N%2BvATuEOOh1ON0Lgy5PmCupKCOrwdy2hRNrMqUhog%2BM%3D`,
    },
    {
      label: "Uniqueness",
      value: 85,
      color: "red",
      image: `http://frontend-shell-547392274449981.1.azure.databricksapps.com/metrics/image?table_name=${dataQualityModalVisible.title}&metric=uniqueness`

      // image: `https://shellrawdata.blob.core.windows.net/shell-dev-container/__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/shell_dev_uc_shell_datasource_25_${dataQualityModalVisible.title}_uniqueness.png?sp=r&st=2025-12-01T05:30:50Z&se=2026-12-01T13:45:50Z&spr=https&sv=2024-11-04&sr=c&sig=N%2BvATuEOOh1ON0Lgy5PmCupKCOrwdy2hRNrMqUhog%2BM%3D`,
    },
  ];

  const matricsDesc = [
    {
      name: "Completeness",
      desc: "Measures the fraction of non-null values present in a column.",
    },
    {
      name: "Distinctness",
      desc: "Measures how many distinct values appear in a column relative to the total number of records.",
    },
    {
      name: "Uniqueness",
      desc: "Measures the proportion of values that occur exactly once in a column.",
    },
    {
      name: "Missing %",
      desc: "The percentage of records with null or missing values in a column.",
    },
    {
      name: "Entropy",
      desc: "A measure of how evenly values are distributed in a column (higher entropy = more diversity).",
    },
    {
      name: "Refresh Rate",
      desc: "How frequently the dataset or field is updated with new or changed records.",
    },
  ];

  return (
    <div className="w-[70%] max-w-7xl bg-white rounded-lg shadow-lg">
      {/* Header */}
      <div className="flex items-start justify-between p-6 border-b border-gray-200">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">
            Data Quality Dashboard
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            {dataQualityModalVisible.title ||
              "Infrastructure Cost Data Product"}
          </p>
        </div>
        <button
          className="text-gray-400 hover:text-gray-600"
          onClick={() => setDataQualityModalVisible(null)}
        >
          <X size={20} />
        </button>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-3 gap-6 p-6">
        {/* Data Veracity Score */}
        <div className="space-y-3 border border-gray-200 rounded-lg border-t-4 border-t-[#0099BA] p-6">
          <div className="flex items-center gap-2">
            {/* <div className="w-1 h-8 bg-teal-500 rounded"></div> */}
            <h3 className="text-sm font-medium text-gray-600">
              Data Quality Score
            </h3>
          </div>
          <div className="text-4xl font-bold text-gray-900">
            {dataQualityModalVisible.score || 95}
          </div>
          {/* <div className="flex items-center gap-1 text-sm text-green-600">
            <TrendingUp size={16} />
            <span>+2 from last month</span>
          </div> */}
        </div>

        {/* Total Rows Processed */}
        <div className="space-y-3 border border-gray-200 rounded-lg border-t-4 border-t-[#00824A] p-6">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-medium text-gray-600">
              Total Rows Processed
            </h3>
          </div>
          <div className="text-4xl font-bold text-gray-900">
            {dataQualityModalVisible.rows || "895,623"}
          </div>
          {/* <div className="flex items-center gap-2 text-sm text-gray-600">
            <Database size={16} />
            <span>From 12 data sources</span>
          </div> */}
        </div>

        {/* Data Points Analyzed */}
        <div className="space-y-3 border border-gray-200 rounded-lg border-t-4 border-t-[#DE8703] p-6">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-medium text-gray-600">
              Metrics Description
            </h3>
          </div>
          <div className="text-xs font-medium italic text-yellow-600 grid grid-cols-2 gap-y-2">
            {/* {matricsDesc.map((item, i) => (
              <p>
                {item.name}{" "}
                <span
                  title={item.desc}
                  className="px-1 py-0.5 font-bold bg-gray-200 rounded-sm cursor-pointer"
                >
                  i
                </span>
              </p>
            ))} */}
            {matricsDesc.map((item, i) => (
              <p key={i} className="flex items-center gap-2">
                {item.name}

                <span
                  id={`metric-tooltip-${i}`}
                  className="px-1 py-0.5 font-bold bg-gray-200 rounded-sm cursor-pointer"
                >
                  i
                </span>

                <Tooltip
                  anchorSelect={`#metric-tooltip-${i}`}
                  place="top"
                  content={item.desc}
                />
              </p>
            ))}
          </div>
          {/* <div className="flex items-center gap-2 text-sm text-gray-600">
            <BarChart3 size={16} />
            <span>Across cost categories</span>
          </div> */}
        </div>
      </div>

      {/* Quality Metrics Grid */}
      <div className="grid grid-cols-3 gap-6 p-6 pt-0">
        {metrics.map((metric, index) => (
          <div
            key={index}
            className="bg-white border border-gray-200 rounded-lg p-6"
          >
            <img
              src={`${metric.image}&_ts=${Date.now()}`}
              key={index}
              alt={`${metric.label} chart`}
              className="w-full h-auto "
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default DataQualityInfoModal;