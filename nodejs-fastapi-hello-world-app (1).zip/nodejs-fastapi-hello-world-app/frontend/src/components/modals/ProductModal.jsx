import React, { useState } from "react";
import { AlertCircle, CheckCircle } from "lucide-react";
import { useAppContext } from "../../context/AppContext";
import { useNavigate } from "react-router-dom";

export default function ProductModal() {
  const { setProductPermission, formData, setFormData } = useAppContext();
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});

  const handleCancel = () => {
    setProductPermission("");
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name?.trim()) {
      newErrors.name = true;
    }

    if (!formData.email?.trim()) {
      newErrors.email = true;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = true;
    }

    if (!formData.department) {
      newErrors.department = true;
    }

    if (!formData.duration) {
      newErrors.duration = true;
    }

    if (!formData.purpose) {
      newErrors.purpose = true;
    }

    return newErrors;
  };

  const handleChange = (name, value) => {
    setFormData({ ...formData, [name]: value });
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: false }));
    }
  };

  const handleSubmit = () => {
    const newErrors = validateForm();

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    navigate("/servicenow");
  };

  const isFormValid = Object.keys(validateForm()).length === 0;

  return (
    <div className="py-1.5 px-1.5 rounded-lg h-full text-xs">
      <div className="max-w-2xl mx-auto h-full">
        {/* Header Banner */}
        <div className="bg-[#FFF4D1] border border-yellow-200 rounded-lg p-1.5 mb-4 flex items-start gap-2">
          <AlertCircle className="w-5 h-5 text-yellow-800 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-800">Requesting Access To:</p>
            <h2 className="text-xs mt-1 text-gray-900">
              Infrastructure Cost Data Product
            </h2>
            <p className="text-[11px] text-gray-700 leading-tight">
              Consolidated financial data for reporting and analytics including
              P&L, balance sheet metrics
            </p>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-3">
          <h3 className="font-semibold text-gray-900 text-sm">
            Access Request Details
          </h3>
          <p className="text-gray-600 text-[11px] mb-2">
            Please provide the following information to process your request
          </p>

          <div>
            {/* Name & Email */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 mb-2">
              <div>
                <label className="block text-[11px] font-medium text-gray-700 mb-1">
                  Requestor Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name || ""}
                  onChange={(e) => handleChange("name", e.target.value)}
                  className={`w-full px-2 py-1.5 border rounded bg-gray-50 text-xs ${
                    errors.name ? "border-red-500" : "border-gray-300"
                  }`}
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-gray-700 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={formData.email || ""}
                  onChange={(e) => handleChange("email", e.target.value)}
                  className={`w-full px-2 py-1.5 border rounded bg-gray-50 text-xs ${
                    errors.email ? "border-red-500" : "border-gray-300"
                  }`}
                />
              </div>
            </div>

            {/* Department / Duration / Purpose */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-1.5 mb-2">
              <div>
                <label className="block text-[11px] font-medium text-gray-700 mb-1">
                  Department <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.department || ""}
                  onChange={(e) => handleChange("department", e.target.value)}
                  className={`w-full px-2 py-1.5 border rounded bg-gray-50 text-xs ${
                    errors.department ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select</option>
                  <option value="finance">Finance</option>
                  <option value="operations">Operations</option>
                  <option value="engineering">Engineering</option>
                  <option value="analytics">Analytics</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-gray-700 mb-1">
                  Access Duration <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.duration || ""}
                  onChange={(e) => handleChange("duration", e.target.value)}
                  className={`w-full px-2 py-1.5 border rounded bg-gray-50 text-xs ${
                    errors.duration ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select</option>
                  <option value="30">30 days</option>
                  <option value="90">90 days</option>
                  <option value="180">180 days</option>
                  <option value="365">1 year</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-gray-700 mb-1">
                  Purpose <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.purpose || ""}
                  onChange={(e) => handleChange("purpose", e.target.value)}
                  className={`w-full px-2 py-1.5 border rounded bg-gray-50 text-xs ${
                    errors.purpose ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <option value="">Select</option>
                  <option value="reporting">Reporting</option>
                  <option value="analysis">Analysis</option>
                  <option value="audit">Audit</option>
                  <option value="planning">Planning</option>
                </select>
              </div>
            </div>

            {/* Justification */}
            <div className="mb-2">
              <label className="block text-[11px] font-medium text-gray-700 mb-1">
                Business Justification
              </label>
              <textarea
                value={formData.justification || ""}
                onChange={(e) =>
                  setFormData({ ...formData, justification: e.target.value })
                }
                className="w-full px-2 py-1.5 border border-gray-300 rounded bg-gray-50 text-xs min-h-[80px]"
              />
              <p className="text-[10px] text-gray-500 mt-1">
                Minimum 50 characters required
              </p>
            </div>

            {/* Data Agreement */}
            <div className="bg-blue-50 border text-[#193CB8] border-blue-200 rounded-lg p-2 mb-2 text-[11px]">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <div>
                  <h4 className="font-semibold text-xs">
                    Data Usage Agreement
                  </h4>
                  <p className="mt-1">
                    By submitting this request, you acknowledge and agree to:
                  </p>
                </div>
              </div>

              <div className="ml-7 space-y-1.5">
                {[
                  "Use the data exclusively for the stated business purpose",
                  "Maintain strict confidentiality and follow security guidelines",
                  "Comply with data governance and regulatory requirements",
                  "Never share access credentials or data with others",
                ].map((item, i) => (
                  <div className="flex items-start gap-1" key={i}>
                    <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                    <p className="text-[11px] leading-tight">{item}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-2 mt-2">
              <button
                type="button"
                onClick={handleCancel}
                className="flex-1 px-3 py-1.5 border border-gray-300 rounded text-xs text-gray-700"
              >
                Cancel
              </button>

              <button
                onClick={handleSubmit}
                disabled={!isFormValid}
                className={`flex-1 px-3 py-1.5 rounded text-xs font-semibold ${
                  isFormValid
                    ? "bg-yellow-400 text-gray-900 hover:bg-yellow-500"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
              >
                Submit Request
              </button>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-2 bg-yellow-50 border border-yellow-200 rounded-md p-2 text-[11px] leading-tight">
          <p className="text-[#894B00]">
            <span className="font-semibold">Note:</span> Your request will be
            reviewed by the data owner and governance team. You'll receive an
            email notification once your request is processed. Typical approval
            time is 2-3 business days.
          </p>
        </div>
      </div>
    </div>
  );
}
