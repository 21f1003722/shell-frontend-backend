import React, { useEffect, useState } from "react";
import { AlertCircle, CheckCircle, X, Loader } from "lucide-react";
import {
  Search,
  Grid,
  HelpCircle,
  Settings,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { FiFilter } from "react-icons/fi";
import { FaBars } from "react-icons/fa";
import { FaStar } from "react-icons/fa";
import { FaRegClock } from "react-icons/fa";
import { IoTrashBinSharp } from "react-icons/io5";
import { MdCancel } from "react-icons/md";
import logo from "../assets/logos/ServiceNow-Symbol.png";
import { useNavigate } from "react-router-dom";
import { useAppContext } from "../context/AppContext";
const BASE_URL = import.meta.env.VITE_API_URL;
import { FaComments } from "react-icons/fa6";

const dummyIncidents = [
  {
    id: "DP-1045",
    date: "10/14/2025 09:43 AM",
    requestedBy: "aarav.mehta",
    department: "Finance",
    duration: "90 days",
    status: "Pending",
  },
  {
    id: "DP-0987",
    date: "10/13/2025 02:10 PM",
    requestedBy: "liam.nguyen",
    department: "Operations",
    duration: "30 days",
    status: "Approved",
  },
  {
    id: "DP-0876",
    date: "10/11/2025 04:22 PM",
    requestedBy: "sophia.tan",
    department: "Engineering",
    duration: "180 days",
    status: "Pending",
  },
  {
    id: "DP-0821",
    date: "10/10/2025 11:57 AM",
    requestedBy: "noah.patel",
    department: "Analytics",
    duration: "1 year",
    status: "Rejected",
  },
  {
    id: "DP-0795",
    date: "10/09/2025 10:33 AM",
    requestedBy: "isabella.rossi",
    department: "Finance",
    duration: "90 days",
    status: "Pending",
  },
];

export default function ServiceNowIncidents({ formData }) {
  const [incidents, setIncidents] = useState([]);
  const [approvalModal, setApprovalModal] = useState({
    show: false,
    incidentId: null,
    adminEmail: "admin@example.com",
    comments: "Everything looks good",
    loading: false,
  });
  const [notification, setNotification] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const {
    finalProducts,
    setFinalProducts,
    productPermission,
    setProductPermission,
    user,
    setMessages,
  } = useAppContext();
  const [ServicenowTable, setServicenowTable] = useState([]);

  const ServiceNowData = async () => {
    try {
      const response = await fetch(`${BASE_URL}/api/approval-logs`);
      const result = await response.json();
      setServicenowTable(result.output);
    } catch (err) {
      console.error("Error fetching incidents:", err);
    } finally {
      setLoading(false); // ← FIX HERE
    }
  };

  useEffect(() => {
    ServiceNowData();
  }, []);

  const [apiIncidents, setApiIncidents] = useState([]);

  useEffect(() => {
    setApiIncidents(ServicenowTable);
  }, [ServicenowTable]);

  useEffect(() => {
    if (formData && Object.keys(formData).length > 0) {
      const newIncident = {
        id: "DP-" + Math.floor(Math.random() * 9000 + 1000),
        approval_status: "pending",
        approved_by: formData.email,
        comments: formData.comments || "",
        date: new Date().toLocaleString(),
        table_name: formData.name,
      };

      // Add local item + keep previous local + keep API data
      setIncidents((prev) => [newIncident, ...prev]);
    }
  }, [formData]);

  useEffect(() => {
    setIncidents((prev) => [...prev, ...apiIncidents]);
  }, [apiIncidents]);

  // React.useEffect(() => {
  //   if (formData && Object.keys(formData).length > 0) {
  //     const newIncident = {
  //       id: `DP-${Math.floor(Math.random() * 9000) + 1000}`,
  //       date: new Date().toLocaleString(),
  //       requestedBy: formData.email,
  //       name: formData.name,
  //       department: formData.department,
  //       duration: formData.duration,
  //       status: "Pending",
  //     };
  //     setIncidents([newIncident, ...dummyIncidents]);
  //   } else {
  //     setIncidents(dummyIncidents);
  //   }
  // }, [formData]);

  const showNotification = (message, type) => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleApproveClick = (incident) => {
    setApprovalModal({
      show: true,
      incidentId: incident.id,
      adminEmail: "",
      comments: "",
      loading: false,
    });
  };

  const handleApprovalSubmit = async () => {
    if (!approvalModal.adminEmail) {
      showNotification("Please enter admin email", "error");
      return;
    }

    const allowedAdmins = [
      "admin1@shell.com",
      "admin2@shell.com",
      "admin3@shell.com",
    ];

    if (!allowedAdmins.includes(approvalModal.adminEmail)) {
      showNotification(
        "You are not authorized to approve this request",
        "error"
      );
      return;
    }

    setApprovalModal((prev) => ({ ...prev, loading: true }));

    try {
      const today = new Date();
      const formattedDate = `${today.getDate()}/${
        today.getMonth() + 1
      }/${today.getFullYear()}`;

      const payload = {
        parameters: {
          id: approvalModal.incidentId || Date.now().toString(),
          approval_status: "approved",
          approved_by: approvalModal.adminEmail,
          comments: approvalModal.comments,
          date: formattedDate,
          table_name: productPermission || "NA",
        },
        // id: approvalModal.incidentId || Date.now().toString(), // or use whatever ID you want
        // approval_status: "approved",
        // approved_by: approvalModal.adminEmail,
        // comments: approvalModal.comments,
        // date: formattedDate,
        // table_name: productPermission || "NA",
      };

      const response = await fetch(`${BASE_URL}/api/admin-approval`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        setIncidents((prev) =>
          prev.map((inc) =>
            inc.id === approvalModal.incidentId
              ? { ...inc, approval_status: "approved" }
              : inc
          )
        );
        // setLoading(false);
        setApprovalModal({
          show: false,
          incidentId: null,
          adminEmail: "",
          comments: "",
          loading: false,
        });
        showNotification("Request approved successfully!", "success");
        setTimeout(() => {
          let unaccessedProducts = finalProducts?.filter(
            (p) => p?.access !== "accessible"
          )?.length;
          --unaccessedProducts;
          setFinalProducts((prev) =>
            prev.map((p) => {
              if (p.table_name === productPermission) {
                return { ...p, access: "accessible" };
              }
              return p;
            })
          );

          setMessages((prev) => [
            ...prev,
            {
              id: Date.now(),
              text: `access granted over "${productPermission || "table"}"`,
              sender: "bot",
              isLoading: false,
              timestamp: new Date().toLocaleTimeString("en-US", {
                hour: "numeric",
                minute: "2-digit",
              }),
            },
            {
              id: Date.now() + 1,
              text:
                unaccessedProducts === 0
                  ? `you have all the required accesses now`
                  : `keep going, you're left with ${
                      unaccessedProducts || "0"
                    } more data ${
                      unaccessedProducts <= 1 ? "table" : "tables'"
                    } access`,
              sender: "bot",
              isLoading: false,
              timestamp: new Date().toLocaleTimeString("en-US", {
                hour: "numeric",
                minute: "2-digit",
              }),
            },
          ]);
          setProductPermission("");
          navigate("/dataProduct");
        }, 2000);
      } else {
        showNotification("Failed to approve request", "error");
      }
    } catch (error) {
      showNotification(`Error: ${error.message}`, "error");
    } finally {
      setApprovalModal((prev) => ({ ...prev, loading: false }));
    }
  };

  const handleReject = (incidentId) => {
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === incidentId ? { ...inc, approval_status: "rejected" } : inc
      )
    );
    showNotification("Request rejected", "info");
  };

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      {/* Top Header */}
      <div className="bg-gray-800 text-white p-3 flex items-center justify-between gap-4 h-10">
        <span className="text-xs flex items-center gap-2">
          <img className="h-16 w-40" src={logo} alt="logo" /> Service Management
        </span>
        <div className="flex items-center justify-end gap-4">
          <Search size={20} />
          <Grid size={20} />
          <HelpCircle size={20} />
          <Settings size={20} />
        </div>
      </div>

      {/* Main Container */}
      <div className="flex" style={{ height: "calc(100vh - 40px)" }}>
        {/* Sidebar */}
        <div className="w-48 bg-gray-800 text-gray-100 flex flex-col gap-4 py-4 overflow-y-auto">
          <nav className="space-y-2 text-sm">
            <div className="rounded font-semibold text-gray-300 relative p-3">
              <input
                className="rounded-lg border border-gray-500 w-[99%]"
                type="text"
                // placeholder="Filter"
              />
              <div className="absolute right-5 top-4">
                <MdCancel />
              </div>
              <div className="absolute left-5 top-4">
                <FiFilter />
              </div>
            </div>
            <div className="flex items-center justify-between p-4 shadow-sm shadow-gray-500">
              <IoTrashBinSharp className="text-white" size={20} />
              <FaStar className="text-white" size={20} />
              <FaRegClock className="text-white" size={20} />
            </div>
            <div className="p-4 text-gray-400 hover:text-gray-200 cursor-pointer">
              Watched Incidents
            </div>
            <div className="px-3 py-2 font-semibold text-gray-300 mt-4">
              Service Desk
            </div>
            <div className="px-3 py-2 text-gray-400 hover:text-gray-200 cursor-pointer">
              Incidents
            </div>
            <div className="px-3 py-2 text-gray-400 hover:text-gray-200 cursor-pointer">
              Create New
            </div>
            <div className="px-3 py-2 text-gray-400 hover:text-gray-200 cursor-pointer">
              Assigned to me
            </div>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col bg-white overflow-hidden">
          {/* Notification */}
          {notification && (
            <div
              className={`p-3 text-sm font-medium flex items-center gap-2 ${
                notification.type === "success"
                  ? "bg-green-100 text-green-800"
                  : notification.type === "error"
                  ? "bg-red-100 text-red-800"
                  : "bg-blue-100 text-blue-800"
              }`}
            >
              <CheckCircle size={18} />
              {notification.message}
            </div>
          )}

          {/* Top Bar */}
          <div className="bg-white border-b p-4 flex items-center gap-2 border-gray-200">
            <button className="flex items-center gap-2 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">
              <FaBars />
            </button>

            <div className="flex items-center gap-2 ml-4">
              <button className="px-3 py-1 text-gray-700 rounded hover:bg-gray-50">
                Incidents
              </button>
              <button className="px-3 py-1 text-white bg-green-800 rounded hover:bg-green-700 text-sm">
                New
              </button>
              <button className="px-3 py-1 text-gray-700 rounded hover:bg-gray-50">
                Search
              </button>
            </div>
            <select className="px-3 py-1 border rounded border-gray-200 text-sm text-gray-700 bg-white">
              <option>Short description</option>
            </select>

            <input
              type="text"
              placeholder="Search"
              className="flex-1 px-3 py-1 border border-gray-200 rounded text-sm"
            />
          </div>

          {/* Filter Info */}
          <div className="px-4 py-2 text-sm text-gray-600 border-b border-gray-200">
            <span className="text-blue-600 cursor-pointer hover:underline">
              All
            </span>
            <span className="mx-2">›</span>
            <span>Showing {incidents.length} requests</span>
          </div>

          {/* Table */}
          <div className="flex-1 overflow-auto">
            {incidents.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <p className="text-gray-500 text-center">
                  No requests yet. Submit a new request to get started.
                </p>
              </div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200 sticky top-0">
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Request Name
                    </th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Request Date
                    </th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Data Product ID
                    </th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Requested By
                    </th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Comments
                    </th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="7" className="py-6 text-center">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-6 w-6 border-4 border-gray-300 border-t-blue-600"></div>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    incidents.map((incident, idx) => (
                      <tr
                        key={idx}
                        className="border-b border-gray-200 hover:bg-gray-50"
                      >
                        <td className="px-4 py-3">
                          <span className="text-blue-600 underline cursor-pointer hover:text-blue-800">
                            Admin Approval
                          </span>
                        </td>
                        <td className="px-4 py-3 text-gray-700">
                          {incident.date}
                        </td>
                        <td className="px-4 py-3 text-gray-700">
                          {incident.id}
                        </td>
                        <td className="px-4 py-3 text-gray-700">
                          {incident.approved_by}
                        </td>
                        <td
                          title={incident.comments || "No comments"}
                          className="px-4 py-3 text-gray-700"
                        >
                          <FaComments />
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-3 py-1 rounded text-xs font-semibold ${
                              incident.approval_status === "approved"
                                ? "bg-green-100 text-green-800"
                                : incident.approval_status === "rejected"
                                ? "bg-red-100 text-red-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {incident.approval_status}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleApproveClick(incident)}
                              disabled={incident.approval_status !== "pending"}
                              className={`px-3 py-1 rounded ${
                                incident.approval_status !== "pending"
                                  ? "bg-gray-300 cursor-not-allowed"
                                  : "bg-green-500 text-white"
                              }`}
                            >
                              Approve
                            </button>

                            {/* <button
                            onClick={() => handleApproveClick(incident)}
                            disabled={incident.approval_status !== "pending"}
                            className="px-3 py-1 text-green-600 border border-green-600 rounded hover:bg-green-50 text-xs font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            ✓ Approve
                          </button> */}
                            <button
                              onClick={() => handleReject(incident.id)}
                              disabled={incident.approval_status !== "pending"}
                              className="px-3 py-1 text-red-600 border border-red-600 rounded hover:bg-red-50 text-xs font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              ✕ Reject
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            )}
          </div>

          {/* Pagination */}
          {incidents.length > 0 && (
            <div className="bg-white border-t border-gray-200 p-4 flex items-center justify-between text-sm">
              <div className="text-gray-600">
                1 to {incidents.length} of {incidents.length}
              </div>
              <div className="flex items-center gap-2">
                <button className="p-1 hover:bg-gray-100 rounded">
                  <ChevronLeft size={18} />
                </button>
                <span className="px-3 py-1 bg-gray-200 rounded">1</span>
                <button className="p-1 hover:bg-gray-100 rounded">
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Approval Modal */}
      {approvalModal.show && (
        <div className="fixed inset-0 backdrop-blur-lg bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                Approve Request
              </h3>
              <button
                onClick={() =>
                  setApprovalModal({
                    show: false,
                    incidentId: null,
                    adminEmail: "",
                    comments: "",
                    loading: false,
                  })
                }
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={20} />
              </button>
            </div>

            <p className="text-sm text-gray-600 mb-4">
              Request ID:{" "}
              <span className="font-semibold">{approvalModal.incidentId}</span>
            </p>

            {/* <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Admin Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                value={formData.email}
                // value={approvalModal.adminEmail}
                onChange={(e) =>
                  setApprovalModal((prev) => ({
                    ...prev,
                    adminEmail: e.target.value,
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                placeholder=""
              />
            </div> */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Admin Email <span className="text-red-500">*</span>
              </label>

              <select
                value={approvalModal.adminEmail}
                onChange={(e) =>
                  setApprovalModal((prev) => ({
                    ...prev,
                    adminEmail: e.target.value,
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 rounded text-sm bg-white"
              >
                <option value="">Select Admin Email</option>
                <option value="admin1@shell.com">admin1@shell.com</option>
                <option value="admin2@shell.com">admin2@shell.com</option>
                <option value="admin3@shell.com">admin3@shell.com</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Comments (Optional)
              </label>
              <textarea
                value={approvalModal.comments}
                onChange={(e) =>
                  setApprovalModal((prev) => ({
                    ...prev,
                    comments: e.target.value,
                  }))
                }
                className="w-full px-3 py-2 border border-gray-300 rounded text-sm min-h-[80px]"
                placeholder="Add any comments..."
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() =>
                  setApprovalModal({
                    show: false,
                    incidentId: null,
                    adminEmail: "",
                    comments: "",
                    loading: false,
                  })
                }
                className="flex-1 px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 hover:bg-gray-50"
                disabled={approvalModal.loading}
              >
                Cancel
              </button>

              <button
                onClick={handleApprovalSubmit}
                disabled={approvalModal.loading}
                className="flex-1 px-4 py-2 bg-green-600 rounded text-sm font-semibold text-white hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {approvalModal.loading ? (
                  <>
                    <Loader size={16} className="animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Approve"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
