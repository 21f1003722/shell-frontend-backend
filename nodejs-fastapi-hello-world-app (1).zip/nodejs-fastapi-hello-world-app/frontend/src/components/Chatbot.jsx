import React, { useState, useRef, useEffect } from "react";
import { Send, Minimize2, X, Sparkles, Loader } from "lucide-react";
import { useAppContext } from "../context/AppContext";
import { useNavigate } from "react-router-dom";
import { IoMdRefresh } from "react-icons/io";

const WSS_URL = import.meta.env.VITE_SOCKET_URL;

export default function Chatbot() {
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);

  const { messages, setMessages, setFinalProducts } = useAppContext();
  const [input, setInput] = useState("");
  const [isMinimized, setIsMinimized] = useState(false);

  const messagesEndRef = useRef(null);
  const wsRef = useRef(null);

  // ---- AUTO SCROLL --------------------------------------------------
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ---- PURE WEBSOCKET SETUP -----------------------------------------
  useEffect(() => {
    connectWebSocket();
    return () => {
      wsRef.current?.close();
    };
  }, []);

  const getDatabricksToken = () => {
    return (
      localStorage.getItem("com.databricks.accessToken") ||
      localStorage.getItem("com.databricks.token") ||
      localStorage.getItem("com.databricks.sessionToken") ||
      localStorage.getItem("token") ||
      ""
    );
  };

  const connectWebSocket = () => {
    const token = getDatabricksToken();
    console.log(
      "Using token from localStorage:",
      token ? "FOUND" : "NOT FOUND"
    );

    const wsUrl = `${WSS_URL}?token=${encodeURIComponent(token)}`;
    console.log("Connecting WebSocket:", wsUrl);

    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      console.log("WebSocket Connected");
    };

    wsRef.current.onclose = () => {
      console.log("Disconnected. Reconnecting...");
      setTimeout(connectWebSocket, 2000);
    };

    wsRef.current.onerror = () => {
      console.log("WebSocket error occurred.");
    };

    wsRef.current.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log("WS RAW:", data);

        if (data.status === "established") return;

        // Check if this is the final message
        if (
          data.is_completed ||
          data.status === "info: executing access_validation_agent"
        ) {
          console.log("Final status reached", data);
          setIsProcessing(false);

          // Add final message
          const finalText = data.message || "Processing complete!";
          addBotMessage(finalText, false);

          // Parse output and navigate if needed
          if (data.output) {
            try {
              const parsed =
                typeof data.output === "string"
                  ? JSON.parse(data.output)
                  : data.output;
              console.log("Parsed output:", parsed);

              let tables =
                parsed?.output_params?.tables ||
                data.output_params?.tables ||
                parsed?.output_params ||
                data.output_params ||
                [];

              tables = Array.isArray(parsed) ? parsed : tables;

              console.log("🔥 FINAL TABLE ARRAY:", tables);

              if (tables.length > 0) {
                setFinalProducts(tables);
                setTimeout(() => navigate("/dataProduct"), 300);
              }
            } catch (err) {
              console.error("Parse fail:", err);
            }
          }

          return;
        }

        // Handle intermediate streaming messages - add each as a separate message
        if (data.message) {
          addBotMessage(data.message, true);
        }
      } catch (err) {
        console.log("Invalid WS message:", event.data, err);
      }
    };
  };

  // ---- MERGE CONSECUTIVE LOADING MESSAGES --------------------------
  const mergeLoadingMessages = (msgs) => {
    const result = [];
    let i = 0;

    while (i < msgs.length) {
      const currentMsg = msgs[i];

      // If it's a bot message with isLoading, collect all consecutive loading messages
      if (currentMsg.sender === "bot" && currentMsg.isLoading) {
        const loadingTexts = [currentMsg.text];
        let j = i + 1;

        // Collect all consecutive loading messages
        while (
          j < msgs.length &&
          msgs[j].sender === "bot" &&
          msgs[j].isLoading
        ) {
          loadingTexts.push(msgs[j].text);
          j++;
        }

        // Create merged message
        result.push({
          ...currentMsg,
          text: loadingTexts.join("\n\n"),
          id: currentMsg.id, // Keep the first message's ID
        });

        i = j; // Skip all merged messages
      } else {
        // Non-loading message, keep as is
        result.push(currentMsg);
        i++;
      }
    }

    return result;
  };

  // ---- ADD BOT MESSAGE --------------------------
  const addBotMessage = (text, isLoading = false) => {
    setMessages((prev) => {
      const newMessages = [
        ...prev,
        {
          id: Date.now() + Math.random(), // Ensure unique ID
          text,
          sender: "bot",
          isLoading,
          timestamp: new Date().toLocaleTimeString("en-US", {
            hour: "numeric",
            minute: "2-digit",
          }),
        },
      ];

      // Merge consecutive loading messages
      return mergeLoadingMessages(newMessages);
    });
  };

  // ---- SEND MESSAGE ---------------------------------------------
  const handleSend = () => {
    if (!input.trim()) {
      return;
    }

    const msg = input.trim();
    console.log("SENDING msg:", msg);

    setInput("");

    // Add user message
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now(),
        text: msg,
        sender: "user",
        timestamp: new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
        }),
      },
    ]);

    // Send to WebSocket
    const payload = { query: msg };
    console.log("WS PAYLOAD:", payload);
    wsRef.current.send(JSON.stringify(payload));
    setIsProcessing(true);
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey && !isProcessing) {
      e.preventDefault();
      handleSend();
    }
  };

  // ---- UI ------------------------------------------
  if (isMinimized) {
    return (
      <div
        className="bg-gradient-to-r from-orange-400 to-pink-300 cursor-pointer hover:shadow-xl transition-shadow p-3"
        onClick={() => setIsMinimized(false)}
      >
        <Sparkles className="w-6 h-6 text-white" />
      </div>
    );
  }

  return (
    <div className="h-screen bg-white flex flex-col overflow-hidden shadow-lg">
      {/* HEADER */}
      <div className="bg-gradient-to-r from-[#FFF4D1] to-[#FECDCA] p-4 h-[76px] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-white rounded-full p-2">
            <Sparkles className="w-5 h-5 text-orange-500" />
          </div>
          <h2 className="text-gray-800 text-lg">Data Product Assistant</h2>
        </div>

        <div className="flex items-center gap-2">
          {/* <button
            onClick={() => setIsMinimized(true)}
            className="text-gray-700 hover:text-gray-900"
          >
            <Minimize2 className="w-5 h-5" />
          </button> */}

          <button
  onClick={() => {      
    if (!isProcessing) {
      sessionStorage.clear();     // 1️⃣ clear session
      navigate("/");              // 2️⃣ go to home
      setTimeout(() => {
        window.location.reload(); // 3️⃣ reload after navigation
      }, 0);
    }
  }}
>
  <IoMdRefresh
    size={20}
    className="w-5 h-5 text-gray-700 hover:text-gray-900"
  />
</button>

        </div>
      </div>

      {/* MESSAGES */}
      <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
        {messages.map((m) => (
          <div key={m.id} className="mb-6">
            <div
              className={`flex ${
                m.sender === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[80%] px-5 rounded-t-2xl py-3 flex items-center gap-2 ${
                  m.sender === "user"
                    ? "bg-[#FFF4D1] text-gray-800 rounded-bl-2xl"
                    : "bg-white text-gray-800 shadow-sm rounded-br-2xl"
                }`}
              >
                {/* {m.isLoading && (
                  <Loader className="w-4 h-4 animate-spin text-gray-600" />
                )} */}
                <p className={`text-sm whitespace-pre-wrap wrap-anywhere`}>
                  {m.text}
                </p>
              </div>
            </div>

            <div
              className={`flex ${
                m.sender === "user" ? "justify-end" : "justify-start"
              } mt-1`}
            >
              <span className="text-xs text-gray-400 px-2">{m.timestamp}</span>
            </div>
          </div>
        ))}

        <div ref={messagesEndRef} />
      </div>

      {/* INPUT */}
      <div className="p-4 bg-white border-t border-gray-100">
        <div className="flex items-end gap-2 bg-gray-50 rounded-xl p-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type....."
            className="flex-1 bg-transparent border-none outline-none resize-none text-sm text-gray-800 placeholder-gray-400 px-2 py-2 max-h-24"
            rows="1"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isProcessing}
            className="bg-[#F7D117] hover:bg-yellow-500 disabled:bg-gray-300 disabled:cursor-not-allowed rounded-full p-3 transition-colors shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-gray-400 mt-2 text-center">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
