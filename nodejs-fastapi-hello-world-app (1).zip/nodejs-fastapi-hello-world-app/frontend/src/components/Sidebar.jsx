import React from "react";
import { Search } from "lucide-react";
import db from '../assets/icons/databricks.svg'
import Dynatrace from '../assets/logos/Dynatrace.svg'
import moogsoft from '../assets/logos/moogsoft.svg'
import ThousandEyes from '../assets/logos/ThousandEyes-Logo.svg'
import graylog from '../assets/logos/graylog.svg'
import solarwinds from '../assets/logos/solarwinds.svg'
import datadog from '../assets/logos/datadog.svg'
import servicenow from '../assets/logos/serviceNow.svg'
import InvoiceOnline from '../assets/logos/InvoiceOnline.svg'
import splunk from '../assets/logos/splunk.svg'
import AzureFeeder from '../assets/logos/AzureFeeder.svg'
import MicrosoftTeams from '../assets/logos/MSTeams.svg'
import SharePoint from '../assets/logos/SharePoint.svg'
import Jira from '../assets/logos/Jira.svg'
import Aternity from '../assets/logos/Aternity.svg'
import { MdManageSearch } from "react-icons/md";

export default function Sidebar() {
  const sources = [
    { name: "dynatrace", logo: Dynatrace},
    { name: "moogsoft", logo: moogsoft },
    { name: "ThousandEyes", logo: ThousandEyes },
    { name: "graylog", logo: graylog },
    { name: "solarwinds", logo: solarwinds },
    { name: "datadog", logo: datadog},
    { name: "servicenow", logo: servicenow },
    { name: "Invoice Online", logo: InvoiceOnline },
    { name: "Azure Feeder Files", logo: AzureFeeder },
    { name: "splunk", logo: splunk },
    { name: "Microsoft Teams", logo: MicrosoftTeams },
    { name: "SharePoint", logo: SharePoint },
    { name: "Jira Software", logo: Jira },
    { name: "Aternity", logo: Aternity }
  ];

  return (
    <div className="w-[164px] h-full bg-white shadow-lg flex flex-col overflow-hidden">

      {/* FIXED HEADER */}
      {/* <div className="bg-[#FFF4D1] py-6 px-4 h-[76px] text-md font-semibold flex flex-col items-center justify-center shrink-0">
        <img src={db}/>
        Data Sources
      </div> */}

      {/* FIXED SEARCH */}
      <div className="p-4 shrink-0">
        <div className="relative">
          <MdManageSearch className="absolute border-r border-[#D1D5DC] pr-0.5 left-2.5 top-1 h-6 w-6 text-gray-400" />
          <input
            type="text"
            placeholder="ServiceNow"
            className="w-full text-xs pl-10 pr-3 py-2 rounded-md border border-[#D1D5DC] bg-[#F3F3F5] text-sm focus:outline-none focus:ring"
          />
        </div>
      </div>

      {/* ONLY THIS PART SCROLLS */}
      <div className="flex-1 flex flex-col gap-4 px-4 pb-6 overflow-y-auto">
        {sources.map((item, i) => (
          <div
            key={i}
            className="border border-[#FEF3C4] rounded-md h-[50px] flex items-center justify-center shadow-sm bg-white hover:bg-gray-50 cursor-pointer transition"
          >
            <img src={item.logo} alt={item.name} className="h-[50px] p-1 object-contain" />
          </div>
        ))}
      </div>

    </div>
  );
}


// import React from "react";
// import { Search } from "lucide-react";
// import db from '../assets/icons/databricks.svg'
// import Dynatrace from '../assets/logos/Dynatrace.svg'
// import moogsoft from '../assets/logos/moogsoft.svg'
// import ThousandEyes from '../assets/logos/ThousandEyes-Logo.svg'
// import graylog from '../assets/logos/graylog.svg'
// import solarwinds from '../assets/logos/solarwinds.svg'
// import datadog from '../assets/logos/datadog.svg'
// import servicenow from '../assets/logos/serviceNow.svg'
// import InvoiceOnline from '../assets/logos/InvoiceOnline.svg'
// import splunk from '../assets/logos/splunk.svg'
// import AzureFeeder from '../assets/logos/AzureFeeder.svg'
// import MicrosoftTeams from '../assets/logos/MSTeams.svg'
// import SharePoint from '../assets/logos/SharePoint.svg'
// import Jira from '../assets/logos/Jira.svg'
// import Aternity from '../assets/logos/Aternity.svg'

// export default function Sidebar() {
//   const sources = [
//     { name: "dynatrace", logo: Dynatrace},
//     { name: "moogsoft", logo: moogsoft },
//     { name: "ThousandEyes", logo: ThousandEyes },
//     { name: "graylog", logo: graylog },
//     { name: "solarwinds", logo: solarwinds },
//     { name: "datadog", logo: datadog},
//     { name: "servicenow", logo: servicenow },
//     { name: "Invoice Online", logo: InvoiceOnline },
//     { name: "Azure Feeder Files", logo: AzureFeeder },
//     { name: "splunk", logo: splunk },
//     { name: "Microsoft Teams", logo: MicrosoftTeams },
//     { name: "SharePoint", logo: SharePoint },
//     { name: "Jira Software", logo: Jira },
//     { name: "Aternity", logo: Aternity }
//   ];

//   return (
//     <div className="w-[164px] h-screen bg-white shadow-lg flex flex-col overflow-hidden ">
//       <div className="bg-[#FFF4D1] py-6 px-4 h-[76px] text-md font-semibold flex flex-col items-center justify-center">
//         <img src={db}/>
//         Data Sources
//       </div>

//       <div className="p-4">
//         <div className="relative">
//           <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
//           <input
//             type="text"
//             placeholder="ServiceNow"
//             className="w-full pl-10 pr-3 py-2 rounded-md border border-[#D1D5DC] bg-[#F3F3F5] text-sm focus:outline-none focus:ring"
//           />
//         </div>
//       </div>

//       <div className="flex flex-col gap-4 px-4 pb-6 overflow-y-auto">
//         {sources.map((item, i) => (
//           <div
//             key={i}
//             className="border border-[#FEF3C4] rounded-md h-[50px] flex items-center justify-center shadow-sm bg-white hover:bg-gray-50 cursor-pointer transition"
//           >
//             <img src={item.logo} alt={item.name} className="h-[50px] p-1 object-contain" />
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }