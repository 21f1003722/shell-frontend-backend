//this is currently not useful made this component dynamic


import React from "react";
import Chatbot from "./Chatbot";
import Sidebar from "./Sidebar";

function LayoutDataProduct({ header, children }) {
  return (
    <div className="flex items-center">
      <div className="min-h-screen bg-gray-50 flex flex-col overflow-hidden w-[75%]">
        {/* Header full width */}
        <header className=" h-[76px] flex items-center bg-white shadow-md p-4 text-xl font-semibold sticky top-0 z-20">
          {header || "Header"}
        </header>

        {/* Body: height = screen - header */}
        <div
          className="flex w-full"
          style={{
            height: "calc(100vh - 76px)",
          }}
        >
          {/* Sidebar */}
          <aside className="w-[164px] border-r shadow-sm bg-white ">
            <Sidebar />
          </aside>

          {/* Content scrolls */}
          <main className="flex-1 p-6 overflow-auto">
            <div className="flex items-center justify-center w-full h-full">
              {children}
            </div>
          </main>
        </div>
      </div>

      <div className="w-[25%]">
        <Chatbot />
      </div>
    </div>
  );
}

export default LayoutDataProduct;
