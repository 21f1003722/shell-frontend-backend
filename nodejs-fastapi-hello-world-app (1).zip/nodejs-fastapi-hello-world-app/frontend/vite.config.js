import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
 
export default defineConfig({
  base: './',          // important for relative asset paths
  plugins: [react(),tailwindcss()],
  //   server: {
  //   proxy: {
  //     "/api": {
  //       target: process.env.VITE_API_BASE_URL,
  //       changeOrigin: true,
  //       secure: false,
  //       rewrite: (path) => path.replace(/^\/api/, ""), // removes /api prefix
  //     },
  //   },
  // },
})
