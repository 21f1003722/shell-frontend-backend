"""
Smart Query Validator for IT4IT queries.
Detects incomplete queries and generates helpful clarification requests.
"""

import logging
import re
from typing import Dict, Any, Optional, List
from backend.config import orchestration_client, AZURE_OPENAI_DEPLOYMENT

logger = logging.getLogger("IT4IT_QueryValidator")


class QueryValidator:
    """
    Validates IT4IT queries for completeness and generates clarifications when needed.
    """
    
    # Keywords that indicate specific IT4IT domains
    DOMAIN_KEYWORDS = [
        'incident', 'problem', 'change', 'service', 'asset', 'configuration',
        'supplier', 'vendor', 'cost', 'financial', 'budget', 'invoice',
        'ticket', 'request', 'catalog', 'sla', 'contract', 'license',
        'inventory', 'hardware', 'software', 'network', 'application'
    ]
    
    # Specific table/entity indicators
    ENTITY_KEYWORDS = [
        'table', 'tables', 'schema', 'database', 'dataset', 'data product',
        'fact', 'dimension', 'dim', 'catalog', 'ledger', 'log', 'record'
    ]
    
    # Generic verbs that need objects
    VAGUE_VERBS = [
        'show', 'get', 'find', 'list', 'display', 'retrieve',
        'analyze', 'compare', 'check', 'build', 'create', 'explain'
    ]
    
    # Confirmation/conversation continuity words
    CONTINUATION_WORDS = [
        'yes', 'no', 'yeah', 'nope', 'sure', 'ok', 'okay', 'thanks',
        'got it', 'great', 'perfect', 'those', 'that', 'them', 'it'
    ]
    
    def __init__(self):
        self.validation_cache = {}
    
    def should_skip_validation(self, query: str, conversation_history: List[Dict]) -> bool:
        """
        Check if validation should be skipped for this query.
        
        Args:
            query: User query
            conversation_history: Previous conversation messages
            
        Returns:
            True if validation should be skipped
        """
        query_lower = query.lower().strip()
        
        # Skip for very short responses that are likely confirmations
        if len(query_lower.split()) <= 2:
            if any(word in query_lower for word in self.CONTINUATION_WORDS):
                logger.info("⏭️ Skipping validation: confirmation/continuation word")
                return True
        
        # Skip if referring to previous context with pronouns
        if conversation_history and len(conversation_history) > 0:
            if any(word in query_lower.split()[:3] for word in ['those', 'that', 'them', 'these', 'it']):
                logger.info("⏭️ Skipping validation: refers to previous context")
                return True
        
        # Skip for greetings (handled by intent classifier)
        greeting_patterns = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening']
        if query_lower in greeting_patterns or query_lower.startswith(tuple(greeting_patterns)):
            logger.info("⏭️ Skipping validation: greeting")
            return True
        
        return False
    
    def is_query_incomplete(self, query: str) -> Dict[str, Any]:
        """
        Determine if a query is incomplete and needs clarification.
        
        Args:
            query: User query string
            
        Returns:
            Dictionary with is_incomplete flag and reasons
        """
        query_lower = query.lower().strip()
        word_count = len(query_lower.split())
        
        logger.info(f"🔍 Validating query: '{query}' ({word_count} words)")
        
        issues = []
        score = 0  # Incompleteness score (higher = more incomplete)
        
        # Issue 1: Very short query (1-3 words)
        if word_count <= 3:
            issues.append("very_short")
            score += 2
            logger.info(f"  ⚠️ Issue: Very short ({word_count} words)")
        
        # Issue 2: No specific domain mentioned
        has_domain = any(domain in query_lower for domain in self.DOMAIN_KEYWORDS)
        if not has_domain:
            issues.append("no_domain")
            score += 1
            logger.info(f"  ⚠️ Issue: No specific domain mentioned")
        
        # Issue 3: No specific entity/table mentioned
        has_entity = any(entity in query_lower for entity in self.ENTITY_KEYWORDS)
        # Also check for schema.table patterns
        has_table_pattern = bool(re.search(r'\b\w+\.\w+\b', query))
        if not has_entity and not has_table_pattern:
            issues.append("no_entity")
            score += 1
            logger.info(f"  ⚠️ Issue: No specific entity/table")
        
        # Issue 4: Only contains vague verbs without clear objects
        query_words = query_lower.split()
        starts_with_vague_verb = query_words[0] in self.VAGUE_VERBS if query_words else False
        if starts_with_vague_verb and word_count <= 4:
            issues.append("vague_verb_only")
            score += 1
            logger.info(f"  ⚠️ Issue: Vague verb without clear object")
        
        # Issue 5: Incomplete sentence (ends with conjunction or preposition)
        incomplete_endings = ['and', 'or', 'for', 'with', 'about', 'of', 'in', 'on']
        if query_words and query_words[-1] in incomplete_endings:
            issues.append("incomplete_sentence")
            score += 2
            logger.info(f"  ⚠️ Issue: Incomplete sentence")
        
        # Issue 6: Single word or fragment
        if word_count == 1:
            issues.append("single_word")
            score += 2
            logger.info(f"  ⚠️ Issue: Single word query")
        
        # Issue 7: Question word only (how, what, which) without elaboration
        question_starters = ['how', 'what', 'which', 'where', 'when']
        if word_count <= 2 and query_words[0] in question_starters:
            issues.append("question_word_only")
            score += 2
            logger.info(f"  ⚠️ Issue: Question word without elaboration")
        
        # Issue 8: Missing time context (forecasted, planned, expected without time period)
        time_indicators = ['forecast', 'forecasted', 'plan', 'planned', 'expect', 'expected', 'predict', 'projected']
        time_periods = ['q1', 'q2', 'q3', 'q4', 'quarter', 'month', 'year', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december', '2024', '2025', 'fy']
        
        has_time_indicator = any(indicator in query_lower for indicator in time_indicators)
        has_time_period = any(period in query_lower for period in time_periods)
        
        if has_time_indicator and not has_time_period:
            issues.append("missing_time_period")
            score += 2
            logger.info(f"  ⚠️ Issue: Time indicator without specific period")
        
        # Issue 9: Missing threshold/criteria (over, under, above, below without value)
        threshold_words = ['over', 'under', 'above', 'below', 'more than', 'less than', 'exceed']
        has_threshold_word = any(word in query_lower for word in threshold_words)
        has_number = any(char.isdigit() for char in query) or any(num in query_lower for num in ['million', 'thousand', 'billion', 'percent', '%'])
        
        if has_threshold_word and not has_number:
            issues.append("missing_threshold_value")
            score += 2
            logger.info(f"  ⚠️ Issue: Threshold word without value")
        
        # Issue 10: Incomplete comparison (compare, difference, vs without second entity)
        comparison_words = ['compare', 'comparison', 'difference', 'versus', 'vs', 'vs.', 'between']
        conjunction_words = ['and', 'to', 'with']
        
        has_comparison = any(word in query_lower for word in comparison_words)
        has_conjunction = any(word in query_lower for word in conjunction_words)
        
        if has_comparison and not has_conjunction and word_count < 6:
            issues.append("incomplete_comparison")
            score += 2
            logger.info(f"  ⚠️ Issue: Comparison without second entity")
        
        # Issue 11: Vague terms without specifics (top, best, worst, high, low, critical without criteria)
        vague_adjectives = ['top', 'best', 'worst', 'high', 'low', 'critical', 'important', 'key', 'main', 'major']
        has_vague_adjective = any(adj in query_lower for adj in vague_adjectives)
        has_criteria = any(word in query_lower for word in ['by', 'based on', 'sorted', 'ranked', 'ordered'])
        
        if has_vague_adjective and not has_criteria and word_count < 8:
            issues.append("vague_ranking")
            score += 1
            logger.info(f"  ⚠️ Issue: Vague ranking/adjective without criteria")
        
        # Issue 12: Ambiguous pronouns or references (this, that, these, those without context)
        if word_count <= 5:
            ambiguous_starters = ['show this', 'get that', 'find these', 'what are those', 'tell me about it']
            if any(query_lower.startswith(starter) for starter in ambiguous_starters):
                issues.append("ambiguous_reference")
                score += 2
                logger.info(f"  ⚠️ Issue: Ambiguous pronoun without context")
        
        # Issue 13: Generic requests without scope (all, everything, any without domain/filters)
        generic_quantifiers = ['all', 'everything', 'any', 'every']
        has_generic = any(quant in query_words for quant in generic_quantifiers)
        has_filter = any(word in query_lower for word in ['where', 'filter', 'with', 'for', 'in', 'from'])
        
        if has_generic and not has_filter and not has_domain and word_count < 6:
            issues.append("too_broad")
            score += 1
            logger.info(f"  ⚠️ Issue: Too broad without filters")
        
        # Issue 14: Questions about "why" or "how" without context
        analytical_starters = ['why', 'how', 'explain']
        if query_words and query_words[0] in analytical_starters and word_count < 5:
            issues.append("needs_more_context")
            score += 1
            logger.info(f"  ⚠️ Issue: Analytical question needs more context")
        
        # Issue 15: Metric without aggregation (cost, spend, revenue without total/average/sum)
        metric_words = ['cost', 'spend', 'revenue', 'expense', 'budget', 'price', 'amount']
        aggregation_words = ['total', 'sum', 'average', 'avg', 'mean', 'max', 'min', 'count', 'by']
        
        has_metric = any(metric in query_lower for metric in metric_words)
        has_aggregation = any(agg in query_lower for agg in aggregation_words)
        
        if has_metric and not has_aggregation and word_count < 6:
            issues.append("metric_without_aggregation")
            score += 1
            logger.info(f"  ⚠️ Issue: Metric without aggregation method")
        
        # Issue 16: Trend/change queries without timeframe
        trend_words = ['trend', 'trends', 'change', 'changes', 'growth', 'decline', 'increase', 'decrease']
        has_trend = any(trend in query_lower for trend in trend_words)
        
        if has_trend and not has_time_period:
            issues.append("trend_without_timeframe")
            score += 1
            logger.info(f"  ⚠️ Issue: Trend query without timeframe")
        
        # Issue 17: Status queries without entity
        status_words = ['status', 'state', 'health', 'condition']
        has_status = any(status in query_lower for status in status_words)
        
        if has_status and not has_entity and not has_domain and word_count < 5:
            issues.append("status_without_entity")
            score += 1
            logger.info(f"  ⚠️ Issue: Status query without entity")
        
        # Issue 18: Count queries without specifics (how many without what)
        count_starters = ['how many', 'count', 'number of']
        has_count = any(starter in query_lower for starter in count_starters)
        
        if has_count and not has_entity and not has_domain and word_count < 4:
            issues.append("count_without_entity")
            score += 2
            logger.info(f"  ⚠️ Issue: Count query without entity")
        
        # Issue 19: Permission/access queries without action
        permission_words = ['access', 'permission', 'permissions', 'rights']
        action_words = ['check', 'verify', 'grant', 'revoke', 'view', 'show', 'list', 'get']
        
        has_permission = any(perm in query_lower for perm in permission_words)
        has_action = any(action in query_lower for action in action_words)
        
        if has_permission and not has_action and word_count < 5:
            issues.append("permission_without_action")
            score += 1
            logger.info(f"  ⚠️ Issue: Permission query without action")
        
        # Issue 20: Filter values without operator (just number without context)
        has_standalone_number = bool(re.search(r'\b\d+\b', query))
        operator_words = ['equal', 'equals', 'greater', 'less', 'more', 'than', 'over', 'under', 'above', 'below']
        has_operator = any(op in query_lower for op in operator_words)
        
        if has_standalone_number and not has_operator and word_count < 7:
            issues.append("value_without_operator")
            score += 1
            logger.info(f"  ⚠️ Issue: Numeric value without operator")
        
        # Decision: Query is incomplete if score >= 3 OR has critical issues
        critical_issues = ['single_word', 'incomplete_sentence', 'question_word_only', 'missing_time_period', 'missing_threshold_value', 'ambiguous_reference', 'count_without_entity']
        has_critical = any(issue in issues for issue in critical_issues)
        
        is_incomplete = score >= 3 or has_critical
        
        logger.info(f"  📊 Incompleteness score: {score}")
        logger.info(f"  🎯 Result: {'INCOMPLETE' if is_incomplete else 'COMPLETE'}")
        
        return {
            "is_incomplete": is_incomplete,
            "issues": issues,
            "score": score,
            "word_count": word_count,
            "has_domain": has_domain,
            "has_entity": has_entity or has_table_pattern
        }
    
    async def generate_clarification(self, query: str, analysis: Dict[str, Any]) -> str:
        """
        Generate a helpful clarification request using LLM.
        
        Args:
            query: Original user query
            analysis: Analysis results from is_query_incomplete()
            
        Returns:
            Clarification message
        """
        logger.info(f"🤖 Generating clarification for: {query}")
        
        # Build context about what's missing
        issues = analysis.get("issues", [])
        missing_items = []
        
        if "no_domain" in issues:
            missing_items.append("IT4IT domain (incident, service, asset, financial, etc.)")
        if "no_entity" in issues:
            missing_items.append("specific tables or data entities")
        if "vague_verb_only" in issues or "question_word_only" in issues:
            missing_items.append("clear action or specific information needed")
        if "missing_time_period" in issues:
            missing_items.append("time period (Q1, Q2, Q3, Q4, month, year)")
        if "missing_threshold_value" in issues:
            missing_items.append("threshold value or percentage")
        if "incomplete_comparison" in issues:
            missing_items.append("what to compare against")
        if "vague_ranking" in issues:
            missing_items.append("ranking criteria (by cost, by count, by priority, etc.)")
        if "ambiguous_reference" in issues:
            missing_items.append("specific reference (what 'this' or 'that' refers to)")
        if "too_broad" in issues:
            missing_items.append("filters or scope (time period, domain, specific criteria)")
        if "needs_more_context" in issues:
            missing_items.append("more context or specific details")
        if "metric_without_aggregation" in issues:
            missing_items.append("aggregation method (total, average, by service, etc.)")
        if "trend_without_timeframe" in issues:
            missing_items.append("time period for trend analysis")
        if "status_without_entity" in issues:
            missing_items.append("what entity to check status for")
        if "count_without_entity" in issues:
            missing_items.append("what to count")
        if "permission_without_action" in issues:
            missing_items.append("action (check, grant, revoke, view)")
        if "value_without_operator" in issues:
            missing_items.append("comparison operator (equal to, greater than, less than)")
        
        missing_context = ", ".join(missing_items) if missing_items else "more context"
        
        prompt = f"""You are a helpful Data Product Copilot assistant. A user asked an incomplete query that needs clarification.

User's query: "{query}"

The query is missing: {missing_context}

Generate a friendly clarification request that:
1. Acknowledges their interest
2. Asks 2-3 specific clarifying questions with examples in bullet points
3. Mentions relevant IT4IT domains they might be interested in (incident, service, asset, financial, supplier, etc.)
4. Keeps it concise and helpful (3-4 sentences with bullets)

Use this structure:
- Opening: "I can help with [topic]! To provide the right information..."
- Questions: Bullet points with specific options
- Closing: Brief invitation to clarify

Your clarification request:"""

        try:
            response = orchestration_client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=250
            )
            
            clarification = response.choices[0].message.content.strip()
            logger.info(f"✅ Generated clarification: {clarification[:100]}...")
            return clarification
            
        except Exception as e:
            logger.error(f"❌ Error generating clarification: {e}")
            
            # Fallback to template-based clarification
            return self._generate_template_clarification(query, analysis)
    
    def _generate_template_clarification(self, query: str, analysis: Dict[str, Any]) -> str:
        """
        Generate a template-based clarification when LLM fails.
        
        Args:
            query: Original user query
            analysis: Analysis results
            
        Returns:
            Template-based clarification message
        """
        issues = analysis.get("issues", [])
        
        # Determine what type of clarification is needed
        if "missing_time_period" in issues:
            return f"""I can help with your query about "{query}", but I need a time period.

Could you specify:
• Which time period? Q1, Q2, Q3, Q4, specific month, or year?
• For example: "What's the forecasted cloud spend for Q4?"

Please provide the time period so I can assist you better!"""
        
        elif "missing_threshold_value" in issues:
            return f"""I can help with your query about "{query}", but I need the threshold value.

Could you specify:
• The percentage or amount (e.g., 20%, $1M, 50%)?
• For example: "services over budget by more than 20%"

Please provide the threshold value!"""
        
        elif "incomplete_comparison" in issues:
            return f"""I can help with your comparison query about "{query}", but I need more details.

Could you specify:
• What do you want to compare? (e.g., Q3 vs Q4, actual vs budget)
• Between which entities or time periods?

Please clarify what you want to compare!"""
        
        elif "vague_ranking" in issues:
            return f"""I can help with "{query}", but I need to know the ranking criteria.

Could you specify:
• Rank by what? (cost, count, priority, frequency, impact?)
• For example: "top 5 services by cost" or "worst incidents by priority"

Please specify your ranking criteria!"""
        
        elif "ambiguous_reference" in issues:
            return f"""I see you're asking about "{query}", but I need more specifics.

Could you clarify:
• What specifically are you referring to?
• Which tables, services, or data are you interested in?

Please provide more details!"""
        
        elif "too_broad" in issues:
            return f"""Your query "{query}" is quite broad. To give you the most relevant results, I need some filters.

Could you specify:
• Time period? (Q1, Q2, this year, last month?)
• Domain? (service, incident, asset, financial?)
• Any specific criteria or filters?

Please narrow down your query!"""
        
        elif "needs_more_context" in issues:
            return f"""I'd like to help with "{query}", but I need more context.

Could you provide:
• What specifically do you want to know about?
• Any particular domain, time period, or entities?
• More details about your question?

Please add more context!"""
        
        elif "metric_without_aggregation" in issues:
            return f"""I can help with "{query}", but I need to know how to aggregate the metric.

Could you specify:
• Total cost? Average cost? Cost by service/department?
• Maximum? Minimum? Sum?
• For example: "total cloud spend" or "average cost by service"

Please specify the aggregation method!"""
        
        elif "trend_without_timeframe" in issues:
            return f"""I can help analyze the trend for "{query}", but I need a timeframe.

Could you specify:
• Over what period? (last 6 months, this year, Q1-Q4?)
• Monthly trend? Quarterly trend? Yearly?
• For example: "cost trend over last 6 months"

Please provide the timeframe!"""
        
        elif "status_without_entity" in issues:
            return f"""I see you're asking about status in "{query}", but I need to know what to check.

Could you specify:
• Status of what? (services, incidents, systems, assets?)
• Which specific entity or domain?
• For example: "status of critical incidents"

Please specify what entity!"""
        
        elif "count_without_entity" in issues:
            return f"""Your query "{query}" asks about count, but I need to know what to count.

Could you specify:
• Count of what? (incidents, services, assets, tickets?)
• In which domain or with what filters?
• For example: "how many open incidents" or "count of active services"

Please specify what to count!"""
        
        elif "permission_without_action" in issues:
            return f"""I see your query about permissions: "{query}", but I need to know what action you want.

Could you specify:
• Check access permissions?
• View current permissions?
• List access rights?
• For example: "check my access to tables" or "show permissions for X"

Please specify the action!"""
        
        elif "value_without_operator" in issues:
            return f"""Your query "{query}" includes a value, but I need a comparison operator.

Could you specify:
• Equal to? Greater than? Less than?
• Over? Under? Between?
• For example: "budget greater than 50000" or "cost equal to 10000"

Please add the comparison operator!"""
        
        elif "no_domain" in issues and "no_entity" in issues:
            return f"""I'd be happy to help with your query about "{query}"! To provide the right information, could you specify:

• **Domain**: Which IT4IT area are you interested in?
  - Service Management (incidents, problems, changes)
  - Asset Management (configuration items, inventory)
  - Financial Management (costs, budgets, chargebacks)
  - Supplier Management (vendors, contracts, spend)

• **Data needed**: What specific information are you looking for?
  - Table names and schemas
  - Data relationships
  - Access permissions
  - Report building

Please provide more details so I can assist you better!"""
        
        elif "no_entity" in issues:
            return f"""I can help with "{query}"! To narrow down the results:

• **Specific tables or entities**: Are you looking for:
  - Specific table names (e.g., incident_fact, service_dim)?
  - All tables in a domain?
  - Relationships between tables?

• **Additional context**:
  - Time period or filters?
  - Summary or detailed data?

What specific information do you need?"""
        
        elif "vague_verb_only" in issues:
            return f"""I see you want to work with "{query}". Could you clarify:

• **Action needed**:
  - Find/list tables?
  - Check access permissions?
  - Build a report or analysis?
  - Understand relationships?

• **Scope**:
  - Specific domain or tables?
  - Any filters or criteria?

Please provide more details!"""
        
        else:
            # Generic fallback
            return f"""I'd like to help with "{query}", but I need a bit more information:

• What specific aspect of IT4IT data are you interested in?
• Are you looking for tables, reports, or access information?
• Any particular domain (service, asset, financial) or timeframe?

Could you provide more details so I can assist you better?"""
    
    async def validate_and_clarify(
        self, 
        query: str, 
        conversation_history: List[Dict] = None
    ) -> Optional[str]:
        """
        Main validation method. Returns clarification message if query is incomplete.
        
        Args:
            query: User query
            conversation_history: Previous conversation messages
            
        Returns:
            Clarification message if incomplete, None if query is complete
        """
        conversation_history = conversation_history or []
        
        # Check if we should skip validation
        if self.should_skip_validation(query, conversation_history):
            return None
        
        # Analyze query completeness
        analysis = self.is_query_incomplete(query)
        
        if not analysis["is_incomplete"]:
            logger.info("✅ Query is complete - no clarification needed")
            return None
        
        # Generate clarification
        logger.info("⚠️ Query is incomplete - generating clarification")
        clarification = await self.generate_clarification(query, analysis)
        
        return clarification


# Global validator instance
query_validator = QueryValidator()