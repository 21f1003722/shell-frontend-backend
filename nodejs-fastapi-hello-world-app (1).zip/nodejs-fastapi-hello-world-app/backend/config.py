"""
Configuration module for IT4IT Agent Orchestrator.
Contains environment variables, constants, and client initialization.
"""

import os
import logging
import httpx
from openai import OpenAI, AzureOpenAI

# -----------------------------------------------------------------------------
# Logging Setup
# -----------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("IT4IT_Config")

# -----------------------------------------------------------------------------
# Azure OpenAI Configuration
# -----------------------------------------------------------------------------
AZURE_OPENAI_ENDPOINT = os.getenv(
    "AZURE_OPENAI_ENDPOINT",
    "https://abhis-mhx1gxed-southindia.cognitiveservices.azure.com"
)
AZURE_OPENAI_KEY = os.getenv(
    "AZURE_OPENAI_KEY",
    "Fkdnh0wN2bacdF3lx0f4VzJKEBX4Yl5BUA9N9aqxzIJU5oSuzwWxJQQJ99BKAC77bzfXJ3w3AAAAACOGaJZs"
)
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")

# -----------------------------------------------------------------------------
# Databricks Configuration
# -----------------------------------------------------------------------------
DATABRICKS_TOKEN = os.getenv(
    "DATABRICKS_TOKEN",
    "dapi65b2f912126b5e3b5f36698fd1b58e0f"
)
DATABRICKS_HOST = os.getenv(
    "DATABRICKS_HOST",
    "https://adb-547392274449981.1.azuredatabricks.net"
)

# Ensure DATABRICKS_HOST has https:// prefix
if not DATABRICKS_HOST.startswith("http"):
    DATABRICKS_HOST = f"https://{DATABRICKS_HOST}"

# -----------------------------------------------------------------------------
# Databricks Job Configuration
# -----------------------------------------------------------------------------
# SET YOUR JOB ID HERE - CHANGE THIS LINE!
DATABRICKS_JOB_ID = int(943738428636861)  # <-- PUT YOUR JOB ID HERE
DATA_QUALITY_JOB_ID = int(446542737497414)
# Example: DATABRICKS_JOB_ID = 987654

# -----------------------------------------------------------------------------
# Databricks Serving Endpoint Model Names
# -----------------------------------------------------------------------------
QUERY_REPHRASER_MODEL = "agents_shell_dev_uc-shell_metadata_agentic_abhi-query_rephraser" #"Rephrase_query"
RETRIEVAL_MODEL ="agents_shell_dev_uc-shell_metadata_agentic_abhi-retrieval_reran" #"retrieval_agent_reranked" #"retrieval_agent_threshold" #"reterival_agent_25"
RESPONSE_GENERATOR_MODEL = "agents_shell_dev_uc-shell_metadata_agentic_abhi-Response_genera" #"response_gen_agent_28" #"response_generation_latest"  # "Query_Response_Generation"

# -----------------------------------------------------------------------------
# Client Initialization
# -----------------------------------------------------------------------------
orchestration_client = None
databricks_client = None


def initialize_clients():
    """Initialize Azure OpenAI and Databricks clients."""
    global orchestration_client, databricks_client
    
    # Initialize Azure OpenAI Client
    try:
        http_client = httpx.Client(
            timeout=90.0,
            limits=httpx.Limits(max_keepalive_connections=5, max_connections=10)
        )
        
        orchestration_client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            http_client=http_client
        )
        logger.info("✓ Azure OpenAI client initialized successfully")
    except Exception as e:
        logger.error(f"❌ Azure OpenAI Client Initialization Error: {e}")
        raise Exception(f"Failed to initialize Azure OpenAI client: {e}")
    
    # Initialize Databricks Client
    try:
        databricks_client = OpenAI(
            api_key=DATABRICKS_TOKEN,
            base_url=f"{DATABRICKS_HOST}/serving-endpoints",
            timeout=90.0,
            max_retries=2
        )
        logger.info("✓ Databricks client initialized successfully")
    except Exception as e:
        logger.error(f"❌ Databricks Client Initialization Error: {e}")
        raise Exception(f"Failed to initialize Databricks client: {e}")
    
    # Log job configuration
    if DATABRICKS_JOB_ID:
        logger.info(f"✓ Databricks Job ID configured: {DATABRICKS_JOB_ID}")
    else:
        logger.warning("⚠️ No Databricks Job ID configured - job triggering disabled")
    
    return orchestration_client, databricks_client


# Initialize clients on module load
initialize_clients()