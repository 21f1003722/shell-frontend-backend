"""
Master Agent orchestrator with Databricks job integration.
"""

import logging
import asyncio
from typing import Dict, Any
from fastapi import WebSocket

from backend.config import orchestration_client, DATABRICKS_JOB_ID
from backend.intent_classifier import classify_intent_fast
from backend.retrieval import retrieve_and_generate_direct
from backend.databricks_job_runner import trigger_and_monitor_job


logger = logging.getLogger("IT4IT_MasterAgent")


class MasterAgent:
    """
    Master Agent with job triggering capability.
    """
    
    def __init__(self, websocket: WebSocket = None):
        if orchestration_client is None:
            raise Exception("Azure OpenAI client not initialized.")
        self.websocket = websocket

    async def _stream_update(self, step: str, status: str, message: str, **kwargs):
        if self.websocket:
            try:
                update = {
                    "step": step,
                    "status": status,
                    "message": message,
                    "timestamp": asyncio.get_event_loop().time(),
                    **kwargs
                }
                await self.websocket.send_json(update)
                logger.info(f"✅ Streamed: {step} - {status} - {message}")
            except Exception as e:
                logger.error(f"❌ Failed to stream update: {e}")

    async def orchestrate(self, user_query: str) -> Dict[str, Any]:
        """
        Orchestration with automatic job triggering for IT4IT queries.
        
        Args:
            user_query: User's input query
        """
        
        logger.info(f"🚀 Orchestrate started for query: {user_query[:100]}")
        logger.info(f"🔌 WebSocket available: {self.websocket is not None}")
        
        await self._stream_update(
            "initialization",
            "started",
            "Starting analysis of your query...",
            reasoning="Preparing to process your question"
        )
        
        # Step 1: Fast intent classification
        await self._stream_update(
            "step_1_classify",
            "executing",
            "Understanding your question type...",
            reasoning="Analyzing query to determine the best approach"
        )
        
        classification = await asyncio.to_thread(classify_intent_fast, user_query)
        intent = classification["intent"]
        
        intent_display = {
            "greeting": "greeting",
            "it4it_query": "business/technical question",
            "general_question": "general knowledge question",
            "unsupported": "unsupported request"
        }
        user_friendly_intent = intent_display.get(intent, intent)
        
        await self._stream_update(
            "step_1_classify",
            "completed",
            f"✓ Question identified as: {user_friendly_intent}",
            intent=intent,
            reasoning=classification["reasoning"],
            confidence=classification.get("confidence", "medium")
        )
        
        # Step 2: Handle based on intent
        if intent == "greeting":
            final_response = (
                "Hello! I'm your IT4IT domain assistant. I can help you with questions "
                "about suppliers, costs, billing cycles, services, systems, and other "
                "business-related topics. What would you like to know?"
            )
            
            await self._stream_update(
                "final_response",
                "completed",
                "✅ Answer ready!",
                content=final_response,
                reasoning="Responded with friendly greeting and service description",
                intent=intent
            )
            
            return {
                "final_response": final_response,
                "intent": intent,
                "steps": 1
            }
        
        elif intent == "general_question":
            final_response = (
                "I specialize in IT4IT domain questions related to business operations, "
                "suppliers, costs, services, and technical systems. Your question seems to "
                "be about general knowledge. If it's related to business or IT operations, "
                "please rephrase it, and I'll be happy to help!"
            )
            
            await self._stream_update(
                "final_response",
                "completed",
                "✅ Answer ready!",
                content=final_response,
                reasoning="Query is outside IT4IT domain, provided guidance",
                intent=intent
            )
            
            return {
                "final_response": final_response,
                "intent": intent,
                "steps": 1
            }
        
        elif intent == "unsupported":
            final_response = (
                "I'm sorry, but I cannot process this request. Please ensure your query "
                "is appropriate and clearly stated."
            )
            
            await self._stream_update(
                "final_response",
                "completed",
                "✅ Response ready",
                content=final_response,
                reasoning="Query cannot be processed",
                intent=intent
            )
            
            return {
                "final_response": final_response,
                "intent": intent,
                "steps": 1
            }
        
        # Step 3: IT4IT Query - Direct retrieval + generation
        elif intent == "it4it_query":
            
            # Direct retrieval and generation
            result = await retrieve_and_generate_direct(user_query, self.websocket)
            
            # Step 4: Automatically trigger Databricks job with context
            job_result = None
            if DATABRICKS_JOB_ID:
                context = result.get("response", "")
                
                if context:
                    await self._stream_update(
                        "job_preparation",
                        "info",
                        f"🔧 Triggering Databricks job {DATABRICKS_JOB_ID} with context...",
                        reasoning="Context retrieved successfully, starting job execution",
                        context_length=len(context),
                        job_id=DATABRICKS_JOB_ID
                    )
                    
                    job_result = await trigger_and_monitor_job(
                        job_id=DATABRICKS_JOB_ID,
                        context=context,
                        websocket=self.websocket
                    )
                else:
                    await self._stream_update(
                        "job_skipped",
                        "warning",
                        "⚠️ Job not triggered - no context available",
                        reasoning="Cannot trigger job without retrieved context"
                    )
            
            # Final response
            await self._stream_update(
                "final_response",
                "completed",
                "✅ Answer ready!",
                content=result["response"],
                reasoning=result["reasoning"],
                intent=intent,
                original_query=user_query,
                rephrased_query=result.get("rephrased_query", user_query),
                retrieval_success=result.get("retrieval_success", False),
                generation_success=result.get("generation_success", False),
                job_triggered=DATABRICKS_JOB_ID is not None and context,
                job_result=job_result
            )
            
            return {
                "final_response": result["response"],
                "intent": intent,
                "original_query": user_query,
                "rephrased_query": result.get("rephrased_query", user_query),
                "context": result.get("context", ""),
                "reasoning": result["reasoning"],
                "steps": 5 if DATABRICKS_JOB_ID else 4,
                "retrieval_success": result.get("retrieval_success", False),
                "generation_success": result.get("generation_success", False),
                "job_triggered": DATABRICKS_JOB_ID is not None and context,
                "job_result": job_result
            }
        
        # Fallback
        else:
            final_response = (
                "I encountered an unexpected situation. Please try rephrasing your question."
            )
            
            await self._stream_update(
                "final_response",
                "completed",
                "✅ Response ready",
                content=final_response,
                reasoning="Unexpected classification result",
                intent=intent
            )
            
            return {
                "final_response": final_response,
                "intent": intent,
                "steps": 1
            }