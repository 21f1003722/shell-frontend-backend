"""
IT4IT Agent Orchestrator with Enhanced Sequential Processing
Version 3.0.0 - Now with HTTP session management for conversation continuity
"""
import os
import logging
from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import requests
import ast


import logging
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any, Optional
import requests
import asyncio

class ApprovalRecord(BaseModel):
    parameters: Optional[Dict[str, Any]]

DATABRICKS_HOST = "https://adb-547392274449981.1.azuredatabricks.net"
DATABRICKS_TOKEN = "dapiba91192873b042045b775ff0a954ec82"
HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json",
}

from backend.routes import (
    health_check,
    get_token,
    query_endpoint,
    websocket_endpoint,
    get_image
)

app = FastAPI(
    title="IT4IT Agent Orchestrator - Enhanced with Session Management",
    description="Orchestration system with conversation continuity, domain extraction, and streaming",
    version="3.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register Routes
app.get("/api/health")(health_check)
app.get("/api/token")(get_token)
app.get("/metrics/image")(get_image)

# Updated query endpoint with session support
@app.post("/api/query")
async def query_route(request: Request, query: dict):
    """
    Query endpoint with session management.
    Pass X-Session-ID header to maintain conversation.
    """
    return await query_endpoint(request, query)

app.websocket("/api/ws/orchestrate")(websocket_endpoint)

@app.post("/api/admin-approval")
async def log_approval(record: ApprovalRecord):
    """Admin approval endpoint for triggering jobs."""
    job_id = 552917062472582

    # Convert all notebook parameters to strings
    params = record.parameters or {}
    parameters = {k: str(v) for k, v in params.items()}

    try:
        job_id = int(job_id)
    except:
        raise HTTPException(status_code=400, detail="job_id must be an integer")

    url = f"{DATABRICKS_HOST}/api/2.1/jobs/run-now"

    payload = {
        "job_id": job_id,
        "notebook_params": parameters,
    }

    try:
        response = await asyncio.to_thread(
            requests.post,
            url,
            headers=HEADERS,
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        run_id = response.json().get("run_id")

        return {
            "status": "success",
            "run_id": run_id,
        }

    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail={
                "error": f"Databricks API run-now failed due to {e}",
                "databricks_response": getattr(e.response, "text", None),
            },
        )


@app.get("/api/approval-logs")
async def get_approval_logs():
    """Trigger approval log job + return child run output."""
    job_id = 979548671801974
    url_run_now = f"{DATABRICKS_HOST}/api/2.1/jobs/run-now"
    url_run_get = f"{DATABRICKS_HOST}/api/2.1/jobs/runs/get"
    url_output = f"{DATABRICKS_HOST}/api/2.1/jobs/runs/get-output"

    # 1️⃣ Trigger job
    try:
        response = await asyncio.to_thread(
            requests.post,
            url_run_now,
            headers=HEADERS,
            json={"job_id": job_id},
            timeout=30,
        )
        response.raise_for_status()
        parent_run_id = response.json().get("run_id")

    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail=f"Databricks run-now failed: {e}"
        )

    # 2️⃣ Poll until parent run is finished
    async def wait_for_completion(run_id):
        while True:
            run_resp = await asyncio.to_thread(
                requests.get,
                url_run_get,
                headers=HEADERS,
                params={"run_id": run_id},
                timeout=20
            )
            run_data = run_resp.json()
            state = run_data.get("state", {}).get("life_cycle_state")

            if state in ["TERMINATED", "SKIPPED", "INTERNAL_ERROR"]:
                return run_data

            await asyncio.sleep(5)

    parent_run_data = await wait_for_completion(parent_run_id)

    # 3️⃣ Extract child run id (usually inside task_runs)
    task_runs = parent_run_data.get("tasks", [])
    if not task_runs:
        raise HTTPException(
            status_code=500,
            detail="No child task run found in parent run."
        )

    child_run_id = task_runs[0].get("run_id")

    # 4️⃣ Get output of child run
    try:
        output_resp = await asyncio.to_thread(
            requests.get,
            url_output,
            headers=HEADERS,
            params={"run_id": child_run_id},
            timeout=20
        )
        output_resp.raise_for_status()
        output_json = output_resp.json()
        notebook_output = output_json['notebook_output']['result']

    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch child run output: {e}"
        )

    # 5️⃣ Return result
    return {
        "output": ast.literal_eval(notebook_output),
    }


# Always keep it at the last of the routes.
# --- Static Files Setup ---
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "dist")
static_dir = os.path.abspath(static_dir)

app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")


# --- Catch-all for React Routes ---
@app.get("/{full_path:path}")
async def serve_react(full_path: str):
    index_html = os.path.join(static_dir, "index.html")
    if os.path.exists(index_html):
        logger.info(f"Serving React frontend for path: /{full_path}")
        return FileResponse(index_html)
    logger.error("Frontend not built. index.html missing.")
    raise HTTPException(
        status_code=404,
        detail="Frontend not built. Please run 'npm run build' first."
    )