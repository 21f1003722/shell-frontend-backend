"""
Session Manager for maintaining conversation state across user interactions.
"""

import logging
import time
from typing import Dict, Any, Optional
from datetime import datetime, timedelta

logger = logging.getLogger("IT4IT_SessionManager")


class SessionManager:
    """
    Manages user sessions with conversation history and pending confirmations.
    """
    
    def __init__(self):
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.SESSION_TIMEOUT = 3600  # 1 hour
        
    def save_session(self, session_id: str, data: Dict[str, Any]):
        """
        Save or update session data.
        
        Args:
            session_id: Unique session identifier
            data: Session data to save
        """
        self.sessions[session_id] = {
            **data,
            "last_updated": time.time()
        }
        logger.info(f"💾 Session saved: {session_id}")
        
    def get_session(self, session_id: str) -> Dict[str, Any]:
        """
        Retrieve session data.
        
        Args:
            session_id: Unique session identifier
            
        Returns:
            Session data or empty dict if not found/expired
        """
        session = self.sessions.get(session_id)
        
        if not session:
            logger.info(f"🆕 New session: {session_id}")
            return {}
        
        # Check if session expired
        last_updated = session.get("last_updated", 0)
        if time.time() - last_updated > self.SESSION_TIMEOUT:
            logger.info(f"⏰ Session expired: {session_id}")
            del self.sessions[session_id]
            return {}
        
        logger.info(f"📂 Session retrieved: {session_id}")
        return session
    
    def clear_session(self, session_id: str):
        """
        Clear a session.
        
        Args:
            session_id: Unique session identifier
        """
        if session_id in self.sessions:
            del self.sessions[session_id]
            logger.info(f"🗑️ Session cleared: {session_id}")
    
    def clear_expired_sessions(self):
        """Clean up expired sessions."""
        current_time = time.time()
        expired = [
            sid for sid, data in self.sessions.items()
            if current_time - data.get("last_updated", 0) > self.SESSION_TIMEOUT
        ]
        
        for sid in expired:
            del self.sessions[sid]
        
        if expired:
            logger.info(f"🧹 Cleaned up {len(expired)} expired sessions")


# Global session manager instance
session_manager = SessionManager()