"""
API routes with session management and conversation handling.
"""

import os
import logging
import requests
import asyncio
import uuid
from fastapi import HTTPException, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import StreamingResponse
from typing import Set

from backend.config import RETRIEVAL_MODEL, RESPONSE_GENERATOR_MODEL
from backend.orchestrator_fixed import MasterAgent
from backend.session_manager import session_manager
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger("IT4IT_Routes")

# Track active WebSocket connections
active_connections: Set[WebSocket] = set()


async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "IT4IT Orchestrator - Enhanced with Conversation",
        "version": "3.0.0",
        "features": [
            "domain_entity_extraction",
            "retrieval_chunks",
            "user_confirmation_flow",
            "conversation_management",
            "session_persistence",
            "output_streaming",
            "sequential_step_logging",
            "http_session_support"
        ],
        "endpoints": [RETRIEVAL_MODEL, RESPONSE_GENERATOR_MODEL],
        "active_connections": len(active_connections),
        "active_sessions": len(session_manager.sessions)
    }


async def get_token():
    """Get Databricks OAuth token."""
    client_id = os.getenv("DATABRICKS_CLIENT_ID")
    client_secret = os.getenv("DATABRICKS_CLIENT_SECRET")

    databricks_host = "https://adb-547392274449981.1.azuredatabricks.net"
    token_url = f"{databricks_host}/oidc/v1/token"

    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": "all-apis",
    }

    response = await asyncio.to_thread(requests.post, token_url, data=payload)

    if response.status_code == 200:
        token = response.json().get("access_token")
        return {
            "message": "Hello, World!",
            "client_id": client_id,
            "token": token,
        }
    else:
        raise HTTPException(
            status_code=response.status_code,
            detail={
                "error": "Failed to retrieve token",
                "response": response.text,
            },
        )


async def query_endpoint(request: Request, query: dict):
    """
    HTTP endpoint for queries WITH session management.
    Now maintains conversation history across requests!
    """
    user_query = query.get("query", "").strip()
    if not user_query:
        raise HTTPException(status_code=400, detail="Query cannot be empty")
    
    # Get or create session ID from header
    session_id = request.headers.get("X-Session-ID")
    is_new_session = False
    
    if not session_id:
        session_id = str(uuid.uuid4())
        is_new_session = True
        logger.info(f"🆕 Created new session: {session_id}")
    else:
        logger.info(f"📂 Using existing session: {session_id}")
    
    # Load session data
    session_data = session_manager.get_session(session_id)
    
    # Log session state
    if session_data:
        history_count = len(session_data.get('history', []))
        has_pending = bool(session_data.get('pending_confirmation'))
        logger.info(f"📊 Session state: {history_count} messages in history, pending_confirmation={has_pending}")
    
    # Create agent with session
    agent = MasterAgent(websocket=None, session_id=session_id)
    result = await agent.orchestrate(user_query, session_data=session_data)
    
    # Save updated session state
    if result.get("session_state"):
        session_manager.save_session(session_id, result["session_state"])
        logger.info(f"💾 Session state saved for {session_id}")
    
    # Return with session ID so client can use it in next request
    return {
        **result,
        "session_id": session_id,
        "is_new_session": is_new_session
    }


async def websocket_endpoint(websocket: WebSocket):
    """
    Enhanced WebSocket endpoint with session management.
    Each WebSocket connection gets a unique session ID.
    """
    await websocket.accept()
    active_connections.add(websocket)
    
    # Generate unique session ID for this connection
    session_id = str(uuid.uuid4())
    logger.info(f"✅ WebSocket connected with session: {session_id} (total: {len(active_connections)})")
    
    # Send session ID to client
    # await websocket.send_json({
    #     "step": "connection",
    #     "status": "connected",
    #     "message": f"✅ Connected with session: {session_id[:8]}...",
    #     "session_id": session_id,
    #     "is_completed": False
    # })

    try:        
        while True:
            try:
                message = await websocket.receive()
                if message["type"] == "websocket.disconnect":
                    break
                
                user_query = ""
                if message["type"] == "websocket.receive":
                    if "text" in message:
                        try:
                            import json
                            data = json.loads(message["text"])
                            user_query = data.get("query", "").strip()
                        except:
                            user_query = message["text"].strip()
                    elif "json" in message:
                        user_query = message["json"].get("query", "").strip()
                
            except Exception as receive_error:
                logger.error(f"Error receiving message: {receive_error}")
                break
            
            if not user_query:
                await websocket.send_json({
                    "step": "validation",
                    "status": "error",
                    "message": "❌ Query cannot be empty",
                    "is_completed": True,
                    "reasoning": "Empty input received"
                })
                continue
            
            logger.info(f"📩 Processing query via WebSocket (session: {session_id[:8]}...): {user_query[:100]}")
            
            # Acknowledge receipt
            await websocket.send_json({
                "step": "query_received",
                "status": "processing",
                "message": f"📝 Processing query: {user_query[:100]}...",
                "is_completed": False,
                "query": user_query
            })
            
            # Load session data
            session_data = session_manager.get_session(session_id)
            
            # Create agent with session
            try:
                agent = MasterAgent(websocket=websocket, session_id=session_id)
                result = await agent.orchestrate(user_query, session_data=session_data)
                
                # Save updated session state
                if result.get("session_state"):
                    session_manager.save_session(session_id, result["session_state"])
                    logger.info(f"💾 Session state saved for {session_id[:8]}...")
                
                # Log result
                logger.info(
                    f"✅ Orchestration completed (session: {session_id[:8]}...):\n"
                    f"   Success: {result.get('success', False)}\n"
                    f"   Job Triggered: {result.get('job_triggered', False)}\n"
                    f"   Awaiting Confirmation: {result.get('awaiting_confirmation', False)}"
                )
                
            except Exception as processing_error:
                logger.error(f"Error processing query: {processing_error}", exc_info=True)
                await websocket.send_json({
                    "step": "processing_error",
                    "status": "error",
                    "message": f"❌ Error: {str(processing_error)}",
                    "is_completed": True,
                })
            
    except WebSocketDisconnect:
        logger.info(f"🔌 Client disconnected gracefully (session: {session_id[:8]}...)")
    except Exception as e:
        logger.error(f"❌ WebSocket error: {str(e)}", exc_info=True)
    finally:
        active_connections.discard(websocket)
        # Note: We keep the session in memory for potential reconnection
        logger.info(f"🔌 WebSocket cleanup complete (remaining: {len(active_connections)})")
        
        # Clean up expired sessions periodically
        session_manager.clear_expired_sessions()
    

# Put your full connection string here
CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=shellrawdata;AccountKey=eFaKnPk/oGFM2Gglxxngu9VK22E9PkM4rfO8MAFPMPsfI2HMSaxTS0T5bW7cAN99B2A6wUVGme0g+AStAY/3hw==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "shell-dev-container"

VOLUME_ROOT = "__unitystorage/catalogs/4808cf09-731a-40c2-90b2-f03373280def/volumes/3d16f77e-3569-467b-b391-1f518e0f162b/plots/"

# Init blob service from connection string
blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
container_client = blob_service_client.get_container_client(CONTAINER_NAME)

# @app.get("/metrics/image")
async def get_image(table_name: str, metric: str):
    filename = f"shell_dev_uc_shell_datasource_25_{table_name}_{metric}.png"
    blob_path = os.path.join(VOLUME_ROOT, filename)

    # Check if blob exists
    blob_client = container_client.get_blob_client(blob_path)
    if not blob_client.exists():
        raise HTTPException(404, detail="Image not found in blob storage")

    # Download as a stream in chunks
    stream = blob_client.download_blob()

    def blob_stream():
        for chunk in stream.chunks():   # Azure handles chunking efficiently
            yield chunk

    # Get mimetype from blob metadata (or default to PNG)
    props = blob_client.get_blob_properties()
    content_type = props.content_settings.content_type or "image/png"

    return StreamingResponse(blob_stream(), media_type=content_type)