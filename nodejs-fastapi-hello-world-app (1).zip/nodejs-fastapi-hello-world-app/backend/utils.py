"""
Fixed utility functions for Databricks API interactions.
Handles MLflow request_id conflicts.
"""

import logging
import uuid
from typing import Dict, Any

from backend.config import (
    databricks_client,
    QUERY_REPHRASER_MODEL,
    RETRIEVAL_MODEL,
    RESPONSE_GENERATOR_MODEL
)

logger = logging.getLogger("IT4IT_Utils")


def call_databricks_serving_endpoint(
    model_name: str, 
    query: str, 
    timeout: int = 60,
    extra_params: Dict[str, Any] = None
) -> str:
    """
    Call Databricks serving endpoint with MLflow request_id conflict handling.
    
    Args:
        model_name: Name of the Databricks serving endpoint
        query: Input query/prompt
        timeout: Request timeout in seconds
        extra_params: Additional parameters to pass to the endpoint
        
    Returns:
        Response content as string
        
    Raises:
        Exception: If endpoint call fails
    """
    try:
        logger.info(f"=" * 80)
        logger.info(f"📡 CALLING DATABRICKS ENDPOINT: {model_name}")
        logger.info(f"🔢 Query length: {len(query)} characters")
        logger.info(f"⏱️ Timeout: {timeout} seconds")
        logger.info(f"📤 Query preview: {query[:200]}...")
        logger.info(f"=" * 80)
        
        # Build request payload
        request_payload = {
            "input": [
                {
                    "role": "user",
                    "content": query
                }
            ]
        }
        
        # Add extra params if provided (but avoid request_id conflicts)
        if extra_params:
            # Filter out request_id to avoid MLflow conflicts
            filtered_params = {k: v for k, v in extra_params.items() if k != 'request_id'}
            if filtered_params:
                request_payload.update(filtered_params)
        
        # Call the endpoint
        response = databricks_client.responses.create(
            model=model_name,
            **request_payload
        )
        
        # Extract content from response
        content = " ".join(
            getattr(content_item, "text", "") 
            for output in response.output 
            for content_item in getattr(output, "content", [])
        )
        
        if content:
            logger.info(f"✅ {model_name} SUCCESS")
            logger.info(f"📊 Response length: {len(content)} characters")
            logger.info(f"📥 Response preview: {content[:200]}...")
            logger.info(f"=" * 80)
            return content
        else:
            logger.warning(f"⚠️ {model_name} returned empty content")
            logger.warning(f"=" * 80)
            return ""
            
    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ {model_name} FAILED")
        logger.error(f"💥 Error: {error_msg}")
        logger.error(f"🔍 Error type: {type(e).__name__}")
        logger.error(f"=" * 80)
        
        # Check if it's the MLflow request_id conflict error
        if "request_id" in error_msg and "Param with key" in error_msg:
            logger.error("🚨 MLflow request_id conflict detected!")
            logger.error("This is likely due to model configuration issues.")
            logger.error("Recommendation: Contact model admin to fix MLflow logging in the model.")
            
            # Try one retry without any extra params
            try:
                logger.info("🔄 Attempting retry with clean request...")
                response = databricks_client.responses.create(
                    model=model_name,
                    input=[{"role": "user", "content": query}]
                )
                
                content = " ".join(
                    getattr(content_item, "text", "") 
                    for output in response.output 
                    for content_item in getattr(output, "content", [])
                )
                
                if content:
                    logger.info(f"✅ Retry successful!")
                    return content
                    
            except Exception as retry_error:
                logger.error(f"❌ Retry also failed: {str(retry_error)}")
        
        raise Exception(f"Endpoint call failed: {error_msg}")


def call_databricks_with_retry(
    model_name: str,
    query: str,
    max_retries: int = 2,
    timeout: int = 60
) -> str:
    """
    Call Databricks endpoint with automatic retry on MLflow conflicts.
    
    Args:
        model_name: Name of the Databricks serving endpoint
        query: Input query/prompt
        max_retries: Maximum number of retry attempts
        timeout: Request timeout in seconds
        
    Returns:
        Response content as string
    """
    last_error = None
    
    for attempt in range(max_retries + 1):
        try:
            if attempt > 0:
                logger.info(f"🔄 Retry attempt {attempt}/{max_retries}")
            
            result = call_databricks_serving_endpoint(
                model_name=model_name,
                query=query,
                timeout=timeout,
                extra_params=None  # Don't pass any extra params to avoid conflicts
            )
            
            return result
            
        except Exception as e:
            last_error = e
            error_msg = str(e)
            
            # If it's not an MLflow error, don't retry
            if "request_id" not in error_msg and "Param with key" not in error_msg:
                logger.error(f"Non-retryable error: {error_msg}")
                raise
            
            # If we've exhausted retries, raise the error
            if attempt == max_retries:
                logger.error(f"❌ All {max_retries} retries exhausted")
                raise
            
            # Wait a bit before retry
            import time
            wait_time = 1 * (attempt + 1)  # Progressive backoff
            logger.info(f"⏳ Waiting {wait_time}s before retry...")
            time.sleep(wait_time)
    
    # Should never reach here, but just in case
    raise last_error


def diagnose_mlflow_error(error_message: str) -> Dict[str, Any]:
    """
    Diagnose MLflow-related errors and provide recommendations.
    
    Args:
        error_message: Error message from the exception
        
    Returns:
        Dictionary with diagnosis and recommendations
    """
    diagnosis = {
        "error_type": "unknown",
        "is_mlflow_error": False,
        "recommendations": []
    }
    
    if "request_id" in error_message and "Param with key" in error_message:
        diagnosis["error_type"] = "mlflow_param_conflict"
        diagnosis["is_mlflow_error"] = True
        diagnosis["recommendations"] = [
            "The serving endpoint's model is logging parameters incorrectly",
            "This is a model-side issue, not a client-side issue",
            "Solutions:",
            "1. Contact the model administrator to fix MLflow logging",
            "2. The model should use nested runs or unique run IDs for each request",
            "3. The model should not log request_id as a parameter",
            "4. As a workaround, you can try using a different model version"
        ]
    elif "mlflow" in error_message.lower():
        diagnosis["error_type"] = "mlflow_general"
        diagnosis["is_mlflow_error"] = True
        diagnosis["recommendations"] = [
            "General MLflow error detected",
            "Check MLflow tracking server connectivity",
            "Verify model logging configuration"
        ]
    
    return diagnosis