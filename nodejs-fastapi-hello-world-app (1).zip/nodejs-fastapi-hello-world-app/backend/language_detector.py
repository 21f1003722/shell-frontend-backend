"""
Language Detection Module for IT4IT Agent Orchestrator.
Ensures queries are in English using a positive check approach.

Instead of checking for every non-English language, we ask:
"Is this English?" - Much simpler and more scalable!
"""

import logging
from typing import Dict, Any, Optional
from backend.config import orchestration_client, AZURE_OPENAI_DEPLOYMENT

logger = logging.getLogger("IT4IT_LanguageDetector")


class LanguageDetector:
    """
    Detects query language and ensures only English queries are processed.
    Uses positive check: "Is this English?" instead of checking every language.
    """
    
    # Polite responses in different languages (optional, for better UX)
    POLITE_RESPONSES = {
        # "hindi": "मुझे खेद है, मैं केवल अंग्रेजी में प्रशिक्षित हूं। कृपया अपना प्रश्न अंग्रेजी में पूछें।",
        # "telugu": "క్షమించండి, నేను ఇంగ్లీష్‌లో మాత్రమే శిక్షణ పొందాను. దయచేసి మీ ప్రశ్నను ఇంగ్లీష్‌లో అడగండి।",
        # "tamil": "மன்னிக்கவும், நான் ஆங்கிலத்தில் மட்டுமே பயிற்சி பெற்றுள்ளேன். தயவுசெய்து உங்கள் கேள்வியை ஆங்கிலத்தில் கேளுங்கள்.",
        "default": "I apologize, but I'm only trained to respond in English. Could you please ask your question in English? Thank you for understanding! 🙏"
    }
    
    def __init__(self):
        self.detection_cache = {}
    
    def quick_detect_non_english(self, query: str) -> bool:
        """
        Quick detection of non-English text.
        Uses positive check: Is this English? If not, reject.
        
        Args:
            query: User query string
            
        Returns:
            True if non-English characters detected
        """
        # Common punctuation/symbols allowed in English
        allowed_special = set("'\".,!?;:()[]{}@#$%&*+-=/\\_<>~`|")
        
        for char in query:
            code_point = ord(char)
            
            # Allow ASCII (0-127)
            if code_point <= 127:
                continue
            
            # Allow common extended ASCII for names/places (128-255)
            if 128 <= code_point <= 255:
                continue
            
            # Anything beyond Latin-1 (256+) is definitely non-English
            if code_point > 255:
                logger.info(f"🚫 Non-Latin character detected: {char} (U+{code_point:04X})")
                return True
        
        # Check ratio of non-ASCII characters (excluding allowed special chars)
        non_ascii_count = sum(1 for char in query if ord(char) > 127 and char not in allowed_special)
        total_chars = len([c for c in query if c not in ' \t\n\r' and c not in allowed_special])
        
        if total_chars > 0:
            non_ascii_ratio = non_ascii_count / total_chars
            if non_ascii_ratio > 0.3:
                logger.info(f"🚫 High non-ASCII ratio: {non_ascii_ratio:.2%}")
                return True
        
        return False
    
    async def detect_language_with_llm(self, query: str) -> Dict[str, Any]:
        """
        Use LLM to detect if the query is in English.
        Simple binary check: English or Not English.
        
        Args:
            query: User query string
            
        Returns:
            Dictionary with language, confidence, and is_english flag
        """
        logger.info(f"🔍 Using LLM to check if query is English: {query[:100]}...")
        
        detection_prompt = f"""You are a language detection system. Analyze if the following text is in English.

            Text: "{query}"

            Rules:
            - If the text is in English (including English with technical terms, abbreviations, or typos) respond: YES
            - If the text is in ANY other language (Spanish, French, German, Irish, Hindi, etc.) respond: NO
            - Mixed language with majority English: NO
            - Mixed language with majority non-English: NO
            - Non-English lanuages that use english characters (e.g., Irish, German, Italian, etc): No

            Your answer (ONLY "YES" or "NO"):"""

        try:
            response = orchestration_client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": detection_prompt}],
                temperature=0,
                max_tokens=5
            )
            
            answer = response.choices[0].message.content.strip().upper()
            is_english = (answer == "YES")
            
            # Try to identify the actual language for better user feedback
            if not is_english:
                # Secondary check to identify the language
                lang_prompt = f"""What language is this text? Respond with ONE WORD only (e.g., spanish, french, hindi, irish, etc.)

                    Text: "{query}"

                    Language:"""
                
                try:
                    lang_response = orchestration_client.chat.completions.create(
                        model=AZURE_OPENAI_DEPLOYMENT,
                        messages=[{"role": "user", "content": lang_prompt}],
                        temperature=0,
                        max_tokens=10
                    )
                    detected_language = lang_response.choices[0].message.content.strip().lower()
                except:
                    detected_language = "non-english"
            else:
                detected_language = "english"
            
            logger.info(f"✅ LLM result: is_english={is_english}, language={detected_language}")
            
            return {
                "language": detected_language,
                "is_english": is_english,
                "confidence": "high",
                "method": "llm"
            }
            
        except Exception as e:
            logger.error(f"❌ LLM language detection failed: {e}")
            # Conservative fallback - if we can't detect, assume non-English to be safe
            return {
                "language": "unknown",
                "is_english": False,
                "confidence": "low",
                "method": "fallback",
                "error": str(e)
            }
    
    async def validate_language(self, query: str) -> Dict[str, Any]:
        """
        Main method to validate if query is in English.
        Uses LLM for all queries for maximum accuracy.
        
        Args:
            query: User query string
            
        Returns:
            Dictionary with validation results and appropriate response
        """
        logger.info(f"🌐 Validating language for query: {query[:100]}...")
        
        # Use LLM to check "Is this English?"
        logger.info(f"🤖 Using LLM to verify if query is English...")
        llm_result = await self.detect_language_with_llm(query)
        
        if not llm_result["is_english"]:
            logger.warning(f"⚠️ Non-English query detected by LLM: {llm_result['language']}")
            
            # Try to provide language-specific response
            detected_lang = llm_result.get("language", "default")
            rejection_msg = self.POLITE_RESPONSES.get(
                detected_lang, 
                self.POLITE_RESPONSES["default"]
            )
            
            return {
                "is_english": False,
                "language": llm_result["language"],
                "confidence": llm_result["confidence"],
                "method": llm_result["method"],
                "should_reject": True,
                "rejection_message": rejection_msg
            }
        
        # Query is in English
        logger.info(f"✅ Query validated as English")
        return {
            "is_english": True,
            "language": "english",
            "confidence": llm_result["confidence"],
            "method": llm_result["method"],
            "should_reject": False
        }
    
    def get_polite_rejection(self, detected_language: Optional[str] = None) -> str:
        """
        Get a polite rejection message for non-English queries.
        
        Args:
            detected_language: Optional detected language for customized response
            
        Returns:
            Polite rejection message
        """
        if detected_language and detected_language in self.POLITE_RESPONSES:
            # Return bilingual response
            native_msg = self.POLITE_RESPONSES[detected_language]
            english_msg = self.POLITE_RESPONSES["default"]
            return f"{native_msg}\n\n{english_msg}"
        
        return self.POLITE_RESPONSES["default"]


# Global language detector instance
language_detector = LanguageDetector()