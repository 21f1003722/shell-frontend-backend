"""
Enhanced Master Agent orchestrator with conversation management and user confirmation.
NOW WITH DYNAMIC GREETING AND GENERAL QUESTION RESPONSES!
FIXED: Handles new business queries when confirmation is pending
"""

import logging
import asyncio
import json
import re
from typing import Dict, Any, List, Optional
from fastapi import WebSocket

from backend.config import orchestration_client, DATABRICKS_JOB_ID, AZURE_OPENAI_DEPLOYMENT, DATA_QUALITY_JOB_ID
from backend.intent_classifier import classify_intent_fast
from backend.retrieval import retrieve_and_generate_enhanced
from backend.databricks_job_runner import trigger_and_monitor_job, trigger_job
from backend.query_validator import query_validator
from backend.language_detector import language_detector


logger = logging.getLogger("IT4IT_MasterAgent")

# Error string that prevents job triggering
BLOCKING_ERROR_SIGNATURE = "No table information found in the provided text"


class ProcessingError(Exception):
    """Custom exception for processing errors that should halt execution"""
    def __init__(self, step: str, message: str, details: Dict[str, Any] = None):
        self.step = step
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class MasterAgent:
    """
    Enhanced Master Agent with conversation management and user confirmation.
    """
    
    def __init__(self, websocket: WebSocket = None, session_id: str = None):
        if orchestration_client is None:
            raise Exception("Azure OpenAI client not initialized.")
        self.websocket = websocket
        self.session_id = session_id
        self.step_counter = 0
        self.stream_log = []
        self.stream_closed = False
        
        # Conversation state
        self.conversation_history = []
        self.pending_confirmation = None
        self.confirmation_timestamp = None
        self.CONFIRMATION_TIMEOUT = 120  # 2 minutes

    async def _stream_update(self, step: str, status: str, message: str, is_completed: bool = False, **kwargs):
        """Stream update and log to stream_log"""
        if self.stream_closed:
            return

        update = {
            "step": step,
            "status": status,
            "message": message,
            "is_completed": is_completed,
            "timestamp": asyncio.get_event_loop().time(),
            **kwargs
        }
        
        self.stream_log.append(update)
        
        if is_completed:
            self.stream_closed = True
        
        if self.websocket:
            try:
                await self.websocket.send_json(update)
                logger.info(f"✅ Streamed: {step} - {status} - {message} (Completed: {is_completed})")
            except Exception as e:
                logger.error(f"❌ Failed to stream update: {e}")

    async def _generate_dynamic_greeting(self, user_query: str) -> str:
        """
        Generate a dynamic, personalized greeting response.
        
        Args:
            user_query: The user's greeting message
            
        Returns:
            A friendly, contextual greeting response
        """
        logger.info(f"🤖 Generating dynamic greeting for: {user_query}")
        
        prompt = f"""You are a Data Product Copilot assistant. A user just greeted you with: "{user_query}"

Respond with a warm, friendly greeting that:
1. Greets them back naturally (matching their tone - formal/casual)
2. Briefly introduces yourself as their Data Product Copilot
3. Mentions you can help with discovering data products across IT4IT domains
4. Ends with an offer to help

Keep it conversational, warm, and concise (2-3 sentences max). Don't use bullet points.

Your greeting:"""

        try:
            response = orchestration_client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=150
            )
            
            greeting = response.choices[0].message.content.strip()
            logger.info(f"✅ Generated greeting: {greeting[:100]}...")
            return greeting
            
        except Exception as e:
            logger.error(f"❌ Error generating greeting: {e}")
            # Fallback to a default greeting
            return "Hi there! I'm your Data Product Copilot. I can help you discover governed data products across IT4IT domains. How can I assist you today?"

    async def _generate_dynamic_out_of_scope_response(self, user_query: str) -> str:
        """
        Generate a dynamic response for general questions or out-of-scope queries.
        
        Args:
            user_query: The user's query
            
        Returns:
            A polite response redirecting to IT4IT capabilities
        """
        logger.info(f"🤖 Generating out-of-scope response for: {user_query[:100]}...")
        
        prompt = f"""You are a Data Product Copilot assistant specialized in IT4IT data products. A user asked: "{user_query}"

This question is outside your expertise area. Generate a polite response that:
1. Acknowledges their question briefly
2. Explains that you're specifically designed to help with IT4IT data products and governed datasets
3. Redirects them by asking if they have any questions about data products or tables in the IT4IT domain
4. Be friendly and helpful, not dismissive

Keep it conversational and warm (2-3 sentences). Don't apologize excessively.

Your response:"""

        try:
            response = orchestration_client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=150
            )
            
            out_of_scope_response = response.choices[0].message.content.strip()
            logger.info(f"✅ Generated out-of-scope response: {out_of_scope_response[:100]}...")
            return out_of_scope_response
            
        except Exception as e:
            logger.error(f"❌ Error generating out-of-scope response: {e}")
            # Fallback to a default response
            return "I'm your Data Product Copilot, specialized in helping with IT4IT data products and governed datasets. I'm here to assist with discovering data products across IT4IT domains. Is there anything related to IT4IT data that I can help you with?"

    async def _generate_dynamic_decline_response(self) -> str:
        """
        Generate a dynamic, short response when user declines permission check.
        
        Returns:
            A friendly, varied decline acknowledgment
        """
        logger.info(f"🤖 Generating dynamic decline response")
        
        prompt = """You are a Data Product Copilot assistant. The user just declined a permission check.

Generate a SHORT, friendly acknowledgment that:
1. Thanks them for their response (varied ways: "I appreciate your response", "No problem", "Understood", "Got it", etc.)
2. Offers to help with other IT4IT data products or tables questions
3. Is VERY concise (1-2 short sentences max, around 15-25 words total)
4. Feels natural and varies in tone (sometimes casual, sometimes professional)

DO NOT mention "governed datasets" or "specifically designed" - keep it simple!

Examples of good responses:
- "I appreciate your response! If you have any questions about data products or tables in the IT4IT domain, I'd be happy to help!"
- "No problem! Let me know if you need help with any other IT4IT data products or tables."
- "Got it! Feel free to ask if you have questions about other data products in IT4IT."
- "Understood! I'm here if you need anything else related to IT4IT data products."

Your short response (vary it, don't repeat the examples):"""

        try:
            response = orchestration_client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.8,  # Higher temperature for more variety
                max_tokens=50
            )
            
            decline_response = response.choices[0].message.content.strip()
            logger.info(f"✅ Generated decline response: {decline_response}")
            return decline_response
            
        except Exception as e:
            logger.error(f"❌ Error generating decline response: {e}")
            # Fallback to a simple default
            return "I appreciate your response! If you have any questions about data products or tables in the IT4IT domain, I'd be happy to help!"

    def _extract_tables_from_context(self, context: str) -> List[str]:
        """
        Extract table names from the context - ENHANCED to handle JSON arrays.
        Looks for:
        1. JSON arrays with table_name field
        2. SCHEMA.TABLE_NAME patterns
        3. Quoted table names
        """
        tables = set()
        
        logger.info(f"📊 Extracting tables from context (length: {len(context)})")
        logger.info(f"🔍 Context preview: {context[:500]}")
        
        # Try to parse as JSON first (handles the array format you're getting)
        try:
            # Check if context looks like JSON
            context_stripped = context.strip()
            if context_stripped.startswith('[') and context_stripped.endswith(']'):
                logger.info("🔍 Context appears to be JSON array, attempting to parse...")
                parsed = json.loads(context_stripped)
                
                if isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, dict) and 'table_name' in item:
                            table_name = item['table_name']
                            tables.add(table_name)
                            logger.info(f"✅ Found table from JSON: {table_name}")
                    
                    if tables:
                        logger.info(f"🎯 Extracted {len(tables)} tables from JSON array")
                        return sorted(list(tables))[:10]  # Return max 10 tables
        except json.JSONDecodeError as e:
            logger.info(f"⚠️ Not valid JSON array: {e}")
        except Exception as e:
            logger.warning(f"⚠️ Error parsing JSON: {e}")
        
        # Pattern 1: SCHEMA.TABLE (e.g., catalog.schema.table or schema.table)
        pattern1 = r'\b[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)?\b'
        
        # Pattern 2: Quoted table names
        pattern2 = r'`([^`]+)`'
        
        # Pattern 3: table_name in JSON-like structures
        pattern3 = r'"table_name"\s*:\s*"([^"]+)"'
        
        # Find all matches
        for match in re.finditer(pattern1, context):
            table = match.group(0)
            if '.' in table:  # Ensure it has schema.table format
                tables.add(table)
                logger.info(f"✅ Found table from pattern: {table}")
        
        for match in re.finditer(pattern2, context):
            tables.add(match.group(1))
            logger.info(f"✅ Found quoted table: {match.group(1)}")
        
        for match in re.finditer(pattern3, context):
            tables.add(match.group(1))
            logger.info(f"✅ Found table from JSON field: {match.group(1)}")
        
        # Filter out common non-table patterns
        filtered_tables = [
            t for t in tables 
            if not any(word in t.lower() for word in ['example', 'sample', 'test'])
        ]
        
        logger.info(f"🎯 Total tables extracted: {len(filtered_tables)}")
        return sorted(list(filtered_tables))[:10]  # Return max 10 tables

    async def _is_confirmation_response(self, user_query: str) -> bool:
        """
        Check if user is responding to the pending confirmation request.
        Returns True only if it's clearly a yes/no response.
        Returns False if it's a new business query.
        """
        if not self.pending_confirmation:
            logger.info("⚠️ No pending confirmation found")
            return False
        
        # Check if confirmation expired
        if self.confirmation_timestamp:
            elapsed = asyncio.get_event_loop().time() - self.confirmation_timestamp
            if elapsed > self.CONFIRMATION_TIMEOUT:
                logger.info(f"⏰ Confirmation expired ({elapsed:.0f}s)")
                return False
        
        query_lower = user_query.lower().strip()
        word_count = len(query_lower.split())
        
        logger.info(f"🔍 Checking if '{user_query}' is a confirmation (word_count={word_count})")
        
        # Single word yes/no responses - DEFINITELY confirmations
        if word_count == 1 and query_lower in ["yes", "no", "yeah", "nope", "sure", "ok", "okay", "yep", "yup"]:
            logger.info(f"✅ Detected single-word confirmation: {query_lower}")
            return True
        
        # Short confirmation phrases (2-4 words)
        confirmation_phrases = [
            "yes please", "yes check", "go ahead", "please check", 
            "check it", "do it", "proceed", "yes go", "sure check",
            "no thanks", "don't check", "skip it", "not now", "no don't"
        ]
        
        if word_count <= 4 and any(phrase in query_lower for phrase in confirmation_phrases):
            logger.info(f"✅ Detected short confirmation phrase in: {user_query}")
            return True
        
        # If longer than 6 words, likely a new query - don't even bother with LLM
        if word_count > 6:
            logger.info(f"❌ Too long ({word_count} words), treating as new query")
            return False
        
        # For medium length (2-6 words), use LLM to determine
        prompt = f"""Is this user response a simple YES or NO answer to a previous question?

User said: "{user_query}"

Context: The system asked if they want to check access permissions on some tables.

Rules:
- If it's a clear yes/no/affirmative/negative response → answer "YES"
- If it's a NEW question or request about data, tables, or business topics → answer "NO"
- If completely unclear → answer "UNCLEAR"

Answer with ONLY one word: "YES", "NO", or "UNCLEAR"

Answer:"""
        
        try:
            response = orchestration_client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=5
            )
            
            answer = response.choices[0].message.content.strip().upper()
            logger.info(f"🤖 LLM classified confirmation: {answer}")
            
            # Only treat as confirmation if LLM says YES
            # If NO or UNCLEAR, treat as new query
            return answer == "YES"
            
        except Exception as e:
            logger.error(f"❌ Error checking confirmation: {e}")
            # On error, assume it's NOT a confirmation (safer to process as new query)
            return False

    async def _process_user_confirmation(self, user_query: str) -> Dict[str, Any]:
        """
        Process user's yes/no confirmation for job triggering.
        """
        query_lower = user_query.lower().strip()
        
        # Check for clear "yes" indicators
        yes_patterns = ["yes", "yeah", "yep", "yup", "sure", "ok", "okay", "go ahead", "proceed", "do it", "check it"]
        is_yes = any(pattern in query_lower for pattern in yes_patterns)
        
        # Check for clear "no" indicators
        no_patterns = ["no", "nope", "don't", "skip", "not now", "cancel"]
        is_no = any(pattern in query_lower for pattern in no_patterns)
        
        if is_no:
            logger.info(f"❌ User declined permission check")
            
            # Clear pending confirmation
            context = self.pending_confirmation.get("context", "")
            self.pending_confirmation = None
            self.confirmation_timestamp = None
            
            # Generate dynamic, short decline response
            decline_response = await self._generate_dynamic_decline_response()
            decline_message = decline_response # \n\nHere's the information I found:\n\n{context}"
            
            await self._stream_update(
                "confirmation_declined",
                "completed",
                decline_message,
                is_completed=True
            )
            
            # Add to conversation history
            self.conversation_history.append({
                "role": "assistant",
                "content": decline_message,
                "timestamp": asyncio.get_event_loop().time()
            })
            
            return {
                "success": True,
                "job_triggered": False,
                "confirmation_declined": True,
                "session_state": self._get_session_state()
            }
        
        elif is_yes:
            logger.info(f"✅ User confirmed - triggering job")
            
            # Get pending data
            tables = self.pending_confirmation.get("tables", [])
            original_query = self.pending_confirmation.get("original_query", "")
            context = self.pending_confirmation.get("context", "")
            user_name = self.pending_confirmation.get("user_name", "")
            
            # Clear pending confirmation
            self.pending_confirmation = None
            self.confirmation_timestamp = None
            
            # await self._stream_update(
            #     "confirmation_accepted",
            #     "processing",
            #     "✅ Great! Triggering access permission check...",
            #     is_completed=False,
            #     tables=tables
            # )
            
            # Trigger Databricks job
            if not DATABRICKS_JOB_ID:
                logger.error("❌ No job ID configured")
                await self._stream_update(
                    "job_error",
                    "failed",
                    "❌ Job triggering is not configured",
                    is_completed=True
                )
                return {
                    "success": False,
                    "error": "No job ID configured",
                    "session_state": self._get_session_state()
                }
            
            try:
                job_result = await trigger_and_monitor_job(
                    job_id=DATABRICKS_JOB_ID,
                    context=context,
                    user_name = user_name,
                    websocket=self.websocket,
                    original_query=original_query
                )
                
                success_message = f"✅ Access check completed!\n\n{context}"
                
                # await self._stream_update(
                #     "job_completed",
                #     "success",
                #     success_message,
                #     is_completed=True,
                #     job_result=job_result
                # )
                
                # Add to conversation history
                self.conversation_history.append({
                    "role": "assistant",
                    "content": success_message,
                    "timestamp": asyncio.get_event_loop().time()
                })
                
                return {
                    "success": True,
                    "job_triggered": True,
                    "job_result": job_result,
                    "session_state": self._get_session_state()
                }
                
            except Exception as e:
                logger.error(f"❌ Job trigger failed: {e}")
                error_message = f"❌ Failed to trigger access check: {str(e)}"
                
                await self._stream_update(
                    "job_error",
                    "failed",
                    error_message,
                    is_completed=True
                )
                
                return {
                    "success": False,
                    "error": str(e),
                    "session_state": self._get_session_state()
                }
        
        else:
            # This should never happen now, but keep as safety net
            logger.warning(f"⚠️ Unclear confirmation response in _process_user_confirmation")
            
            clarification_message = "I didn't quite catch that. Please respond with 'yes' to check permissions or 'no' to skip."
            
            await self._stream_update(
                "clarification_needed",
                "pending",
                clarification_message,
                is_completed=True,
                requires_user_input=True
            )
            
            return {
                "success": True,
                "awaiting_confirmation": True,
                "clarification_needed": True,
                "session_state": self._get_session_state()
            }

    def _get_session_state(self) -> Dict[str, Any]:
        """Get current session state for persistence."""
        return {
            "history": self.conversation_history,
            "pending_confirmation": self.pending_confirmation,
            "confirmation_timestamp": self.confirmation_timestamp
        }

    def _restore_session_state(self, session_data: Dict[str, Any]):
        """Restore session state from previous interactions."""
        if not session_data:
            return
        
        self.conversation_history = session_data.get("history", [])
        self.pending_confirmation = session_data.get("pending_confirmation")
        self.confirmation_timestamp = session_data.get("confirmation_timestamp")
        
        logger.info(f"🔄 Restored session state: {len(self.conversation_history)} messages, "
                   f"pending={bool(self.pending_confirmation)}")

    async def _generate_error_summary(self, error: ProcessingError) -> Dict[str, Any]:
        """Generate a user-friendly error summary."""
        return {
            "step_failed": error.step,
            "error_message": error.message,
            "details": error.details,
            "timestamp": asyncio.get_event_loop().time()
        }

    async def orchestrate(self, user_query: str, session_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Enhanced orchestration with conversation and confirmation handling.
        FIXED: Now handles new business queries when confirmation is pending.
        """
        try:
            # Restore session state if provided
            if session_data:
                self._restore_session_state(session_data)
            
            # Add user query to conversation history
            self.conversation_history.append({
                "role": "user",
                "content": user_query,
                "timestamp": asyncio.get_event_loop().time()
            })
            
            # ============================================================================
            # STEP -1: LANGUAGE VALIDATION (Check if query is in English)
            # ============================================================================
            # await self._stream_update(
            #     "language_validation",
            #     "processing",
            #     "🌐 Validating query language...",
            #     is_completed=False
            # )
            
            language_result = await language_detector.validate_language(user_query)
            
            if not language_result["is_english"]:
                # Query is not in English - reject politely
                logger.warning(f"🚫 Non-English query detected: {language_result['language']}")
                
                rejection_message = language_result["rejection_message"]
                
                # CRITICAL: Preserve ALL session context and provide helpful instructions
                context_info = []
                
                # Check if there's a pending confirmation
                if self.pending_confirmation:
                    tables = self.pending_confirmation.get("tables", [])
                    logger.info(f"⚠️ Non-English response while confirmation pending for {len(tables)} tables")
                    context_info.append(
                        f"I'm waiting for your confirmation to check access permissions on:\n"
                        f"• {', '.join(tables[:3])}"
                        f"{' and others' if len(tables) > 3 else ''}\n\n"
                        f"Please respond with 'yes' or 'no' in English."
                    )
                
                # Check if we were in middle of a conversation
                elif len(self.conversation_history) > 1:
                    # Look at the last assistant message to understand context
                    last_assistant_msg = None
                    for msg in reversed(self.conversation_history[:-1]):  # Exclude current user message
                        if msg.get("role") == "assistant":
                            last_assistant_msg = msg
                            break
                    
                    if last_assistant_msg:
                        msg_type = last_assistant_msg.get("type", "response")
                        content_preview = last_assistant_msg.get("content", "")[:150]
                        
                        logger.info(f"⚠️ Non-English response in ongoing conversation (last message type: {msg_type})")
                        
                        if msg_type == "clarification_request":
                            context_info.append(
                                "I asked you a clarification question about your query.\n\n"
                                "Please provide your answer in English."
                            )
                        else:
                            context_info.append(
                                "We were having a conversation about your IT4IT query.\n\n"
                                "Please continue in English so I can help you better."
                            )
                
                # Build enhanced rejection message with context
                if context_info:
                    rejection_message = (
                        f"{rejection_message}\n\n"
                        f"📋 **Context**:\n"
                        f"{chr(10).join(context_info)}"
                    )
                    logger.info(f"💡 Preserving full session context - user can continue in English")
                else:
                    logger.info(f"💡 New conversation - asking user to start in English")
                
                await self._stream_update(
                    "language_validation",
                    "rejected",
                    rejection_message,
                    is_completed=True,
                    language_detected=language_result["language"],
                    confidence=language_result["confidence"],
                    session_preserved=True,
                    pending_confirmation_active=bool(self.pending_confirmation),
                    conversation_context_available=len(self.conversation_history) > 1
                )
                
                # Add rejection to conversation history
                self.conversation_history.append({
                    "role": "assistant",
                    "content": rejection_message,
                    "timestamp": asyncio.get_event_loop().time(),
                    "type": "language_rejection"
                })
                
                # IMPORTANT: Return complete session state - ALL context preserved!
                return {
                    "success": False,
                    "language_rejected": True,
                    "language_detected": language_result["language"],
                    "message": rejection_message,
                    "session_preserved": True,
                    "awaiting_confirmation": bool(self.pending_confirmation),
                    "has_conversation_history": len(self.conversation_history) > 1,
                    "session_state": self._get_session_state()  # Preserves EVERYTHING
                }
            
            # Query is in English - proceed
            # logger.info(f"✅ Language validated: English (confidence: {language_result['confidence']})")
            # await self._stream_update(
            #     "language_validation",
            #     "completed",
            #     "✅ Language: English",
            #     is_completed=False,
            #     language="english",
            #     confidence=language_result["confidence"]
            # )
            
            # ============================================================================
            # STEP 0: INTENT CLASSIFICATION (Always do this first)
            # ============================================================================
            await self._stream_update(
                "intent_classification",
                "processing",
                "🎯 Analyzing intent",
                is_completed=False
            )
            
            classification = classify_intent_fast(user_query)
            intent = classification.get("intent", "it4it_query")
            
            logger.info(f"🎯 CLASSIFIED INTENT: {intent}")
            
            await self._stream_update(
                "intent_classification",
                "completed",
                f"✅ Intent: {intent}",
                is_completed=False,
                intent=intent,
                reasoning=classification.get("reasoning", "")
            )
            
            # ============================================================================
            # CHECK IF THIS IS A CONFIRMATION RESPONSE (only if pending confirmation exists)
            # AND if intent is not clearly a new IT4IT query
            # ============================================================================
            if self.pending_confirmation:
                is_confirmation = await self._is_confirmation_response(user_query)
                
                if is_confirmation:
                    logger.info(f"🔄 Processing as confirmation response: {user_query}")
                    return await self._process_user_confirmation(user_query)
                else:
                    # User asked a NEW query while confirmation was pending
                    # Clear the pending confirmation and process as new query
                    logger.info(f"🆕 New query detected while confirmation pending - clearing pending state")
                    logger.info(f"📋 Discarding pending confirmation for tables: {self.pending_confirmation.get('tables', [])}")
                    
                    # Inform user we're moving on
                    await self._stream_update(
                        "confirmation_skipped",
                        "info",
                        "📋 Moving on to your new question (previous confirmation skipped)",
                        is_completed=False
                    )
                    
                    self.pending_confirmation = None
                    self.confirmation_timestamp = None
                    # Continue processing as normal query below
            
            # ============================================================================
            # HANDLE GREETINGS AND OUT-OF-SCOPE QUERIES WITH DYNAMIC RESPONSES
            # ============================================================================
            if intent in ["greeting", "general_question", "unsupported"]:
                logger.info(f"🔄 Handling {intent} with dynamic response")
                
                if intent == "greeting":
                    # Generate dynamic greeting
                    final_response = await self._generate_dynamic_greeting(user_query)
                else:
                    # Generate dynamic out-of-scope response
                    final_response = await self._generate_dynamic_out_of_scope_response(user_query)
                
                # Add to conversation history
                self.conversation_history.append({
                    "role": "assistant",
                    "content": final_response,
                    "timestamp": asyncio.get_event_loop().time()
                })
                
                await self._stream_update(
                    "final_response",
                    "completed",
                    final_response,
                    is_completed=True,
                    intent=intent
                )
                return {
                    "final_response": final_response,
                    "success": True,
                    "session_state": self._get_session_state()
                }
            
            # ============================================================================
            # IT4IT QUERY PROCESSING (STEPS 1-4: Retrieval & Generation)
            # ============================================================================
            elif intent == "it4it_query":
                
                # ============================================================================
                # QUERY VALIDATION - Check if IT4IT query is complete (ONLY FOR IT4IT QUERIES)
                # ============================================================================
                logger.info(f"🔍 Validating query completeness...")
                
                clarification_needed = await query_validator.validate_and_clarify(
                    user_query,
                    self.conversation_history
                )
                
                if clarification_needed:
                    logger.info(f"⚠️ Query needs clarification")
                    
                    # Add clarification to conversation history
                    self.conversation_history.append({
                        "role": "assistant",
                        "content": clarification_needed,
                        "type": "clarification_request",
                        "timestamp": asyncio.get_event_loop().time()
                    })
                    
                    await self._stream_update(
                        "query_validation",
                        "needs_clarification",
                        clarification_needed,
                        is_completed=True,
                        requires_user_input=True
                    )
                    
                    return {
                        "success": True,
                        "needs_clarification": True,
                        "clarification_message": clarification_needed,
                        "session_state": self._get_session_state()
                    }
                
                logger.info(f"✅ Query validation passed - proceeding with retrieval")
                
                # ============================================================================
                # RETRIEVAL & GENERATION (Query is complete, proceed normally)
                # ============================================================================
                
                try:
                    result = await retrieve_and_generate_enhanced(user_query, self.websocket)
                    
                    if not result.get("retrieval_success", False):
                        raise ProcessingError(step="retrieval", message="Failed to retrieve relevant documents")
                    
                except Exception as e:
                    raise ProcessingError(step="retrieval_generation", message=f"Retrieval pipeline failed: {str(e)}")
                
                context = result.get("response", "")
                
                # ============================================================================
                # EXTRACT TABLES AND ASK FOR CONFIRMATION
                # ============================================================================
                tables = self._extract_tables_from_context(context)
                
                if tables and not BLOCKING_ERROR_SIGNATURE in context:
                    # Found tables - ask user for confirmation
                    logger.info(f"📊 Found {len(tables)} tables: {tables}")
                    
                    # Save pending state
                    self.pending_confirmation = {
                        "context": context,
                        "tables": tables,
                        "original_query": user_query
                    }
                    self.confirmation_timestamp = asyncio.get_event_loop().time()

                    
                    data_quality_job_triggered = await trigger_job(
                        job_id=DATA_QUALITY_JOB_ID,
                        context=context,
                    )

                    if data_quality_job_triggered:
                        await self._stream_update(
                            "pending",
                            "Data Quality job triggered",
                            "Checking Data Quality"
                        )
                        logger.info(f"{data_quality_job_triggered}")

                    output = json.loads(context)

                    for i in output:
                        if isinstance(i, dict):
                            if 'table_description' in i:
                                i['business_glossary'] = i.pop('table_description')
                            if 'owner' in i:
                                i['user_name'] = i.pop('owner')
                    
                    # Show tables to user and ask for confirmation
                    tables_list = "\n".join([f"  • {table}" for table in tables])
                    confirmation_message = f"📊 I found the following tables:\n{tables_list}\n\nWould you like me to check access permissions on these tables?"
                    
                    await self._stream_update(
                        "awaiting_confirmation",
                        "pending",
                        confirmation_message,
                        is_completed=True,
                        requires_user_input=True,
                        tables=tables,
                        context_preview=context,
                        output=output
                    )
                    
                    # Add to conversation history
                    self.conversation_history.append({
                        "role": "assistant",
                        "content": confirmation_message,
                        "type": "confirmation_request",
                        "timestamp": asyncio.get_event_loop().time()
                    })
                    
                    logger.info(f"✅ Saved pending confirmation with {len(tables)} tables")
                    
                    return {
                        "success": True,
                        "awaiting_confirmation": True,
                        "tables": tables,
                        "session_state": self._get_session_state()
                    }
                
                else:
                    # No tables found or blocking error
                    if BLOCKING_ERROR_SIGNATURE in context:
                        logger.warning(f"🛑 Blocking error detected")
                        
                        await self._stream_update(
                            "no_tables_found",
                            "completed",
                            "🛑 No relevant table information found for your query.",
                            is_completed=True,
                            reasoning="Agent returned empty/error response"
                        )
                        
                        # Add to conversation history
                        self.conversation_history.append({
                            "role": "assistant",
                            "content": context,
                            "type": "error",
                            "timestamp": asyncio.get_event_loop().time()
                        })
                        
                        return {
                            "final_response": context,
                            "success": False,
                            "job_triggered": False,
                            "session_state": self._get_session_state()
                        }
                    else:
                        # No tables but valid response
                        await self._stream_update(
                            "final_response",
                            "completed",
                            "✅ Here's what I found (no access check needed):",
                            is_completed=True,
                            final_response=context
                        )
                        
                        # Add to conversation history
                        self.conversation_history.append({
                            "role": "assistant",
                            "content": context,
                            "timestamp": asyncio.get_event_loop().time()
                        })
                        
                        return {
                            "success": True,
                            "job_triggered": False,
                            "session_state": self._get_session_state()
                        }
            
            else:
                # Fallback
                await self._stream_update(
                    "final_response",
                    "completed",
                    "✅ Response ready",
                    is_completed=True,
                    content="Unexpected situation."
                )
                return {
                    "success": True,
                    "session_state": self._get_session_state()
                }
        
        except ProcessingError as e:
            logger.error(f"❌ ORCHESTRATION FAILED: {e.message}")
            error_summary = await self._generate_error_summary(e)
            
            await self._stream_update(
                "processing_error",
                "failed",
                f"❌ Processing failed: {e.message}",
                is_completed=True,
                processing_summary=error_summary
            )
            return {
                "success": False,
                "error": str(e),
                "session_state": self._get_session_state()
            }
        
        except Exception as e:
            logger.error(f"❌ UNEXPECTED ERROR: {str(e)}")
            await self._stream_update(
                "unexpected_error",
                "failed",
                "❌ Unexpected error occurred",
                is_completed=True,
                error_message=str(e)
            )
            return {
                "success": False,
                "error": str(e),
                "session_state": self._get_session_state()
            }