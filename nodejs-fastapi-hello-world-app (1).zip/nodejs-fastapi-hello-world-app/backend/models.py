"""
Pydantic models for request/response validation.
"""

from pydantic import BaseModel
from typing import Dict, Any, Optional


class ApprovalRecord(BaseModel):
    """Model for approval records."""
    parameters: Optional[Dict[str, Any]] = None


class TriggerJobRequest(BaseModel):
    """Model for triggering Databricks jobs."""
    job_id: int
    context: str
    

class QueryRequest(BaseModel):
    """Model for user query requests."""
    query: str

class ApprovalRecord(BaseModel):
    parameters: Optional[Dict[str, Any]]