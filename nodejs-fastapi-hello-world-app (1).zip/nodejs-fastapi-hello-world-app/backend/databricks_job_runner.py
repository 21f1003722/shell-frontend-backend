"""
Databricks job trigger and monitoring.
Updated to filter out 'No output is available' transient errors.
"""

import logging
import asyncio
import time
import json
import requests
from typing import Dict, Any, Optional
from fastapi import WebSocket

from backend.config import DATABRICKS_HOST, DATABRICKS_TOKEN

logger = logging.getLogger("IT4IT_JobRunner")

# CRITICAL: This must match the Task Key in Databricks exactly
FINAL_TASK_KEY = "access_validation_agent"

# Error message to ignore
IGNORE_ERROR_MSG = "No output is available until the task begins"

async def trigger_and_monitor_job(
    job_id: int,
    context: str,
    user_name: str,
    websocket: WebSocket = None,
    original_query: str = None  # Added for backward compatibility
) -> Dict[str, Any]:
    
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    
    async def _stream_update(step: str, status: str, message: str, is_completed: bool = False, **kwargs):
        if websocket:
            await websocket.send_json({
                "step": step,
                "status": status,
                "message": message,
                "is_completed": is_completed,
                "timestamp": time.time(),
                **kwargs
            })
            if is_completed or status == "error":
                logger.info(f"[Job] {step} - {message} (Done: {is_completed})")
    
    try:
        # Log original query if provided
        if original_query:
            logger.info(f"📝 Original Query: {original_query[:100]}...")
        
        # Step 1: Trigger
        await _stream_update("job_trigger", "executing", "Verifying your access...", is_completed=False)
        
        trigger_url = f"{DATABRICKS_HOST}/api/2.1/jobs/run-now"
        trigger_payload = {"job_id": job_id, "notebook_params": {"context": context, "user_name" : user_name}}
        
        trigger_response = await asyncio.to_thread(requests.post, trigger_url, headers=headers, json=trigger_payload, timeout=30)
        
        if trigger_response.status_code != 200:
            raise Exception(f"Job trigger failed: {trigger_response.text}")
        
        run_id = trigger_response.json()["run_id"]
        
        # await _stream_update("job_triggered", "success", f"Access Validatio Job Running", is_completed=False)
        
        # Step 2: Poll
        run_url = f"{DATABRICKS_HOST}/api/2.1/jobs/runs/get"
        output_url = f"{DATABRICKS_HOST}/api/2.1/jobs/runs/get-output"
        
        last_state = None
        seen_outputs = set()
        
        logger.info(f"👀 Watching for Task Key: '{FINAL_TASK_KEY}'")

        while True:
            await asyncio.sleep(2)
            
            # Get Job Status
            status_response = await asyncio.to_thread(requests.get, run_url, headers=headers, params={"run_id": run_id}, timeout=30)
            if status_response.status_code != 200:
                continue
            
            run_data = status_response.json()
            state = run_data.get("state", {})
            life_cycle_state = state.get("life_cycle_state")
            
            if life_cycle_state != last_state:
                # await _stream_update("job_status", "info", f"📊 Job State: {life_cycle_state}", is_completed=False, state=life_cycle_state, run_id=run_id)
                last_state = life_cycle_state
            
            # --- PROCESS TASKS ---
            tasks = run_data.get("tasks", [])
            
            for task in tasks:
                task_key = task.get("task_key")
                task_run_id = task.get("run_id")
                
                if not task_run_id:
                    continue
                
                try:
                    task_output_resp = await asyncio.to_thread(requests.get, output_url, headers=headers, params={"run_id": task_run_id}, timeout=30)
                    if task_output_resp.status_code == 200:
                        data = task_output_resp.json()
                        
                        # Is this the agent we are waiting for?
                        is_final_task = (task_key == FINAL_TASK_KEY)
                        
                        if "notebook_output" in data:
                            nb = data["notebook_output"]
                            
                            # CHECK 1: Notebook Exit Result (dbutils.notebook.exit)
                            if "result" in nb:
                                result_text = nb["result"]
                                res_key = f"{task_run_id}_result"

                                output = json.loads(result_text)

                                output = output["output_params"]['tables']


                                if result_text and res_key not in seen_outputs:
                                    seen_outputs.add(res_key)
                                    await _stream_update(
                                        "notebook_result", 
                                        "info", 
                                        f"Unfortunately, you do not have access to these tables at the moment. Kindly request access in order to proceed.", 
                                        is_completed=is_final_task, 
                                        output=output, 
                                        run_id=run_id,
                                    )
                                    if is_final_task:
                                        logger.info(f"🛑 Found RESULT in '{FINAL_TASK_KEY}'. Stopping.")
                                        return {"success": True, "run_id": run_id, "stream_stopped_early": True}

                            # CHECK 2: Cell Outputs (Print statements)
                            if "cell_outputs" in nb:
                                for idx, cell in enumerate(nb["cell_outputs"]):
                                    cell_key = f"{task_run_id}_cell_{idx}"
                                    if cell_key not in seen_outputs:
                                        seen_outputs.add(cell_key)
                                        out_txt = cell.get("output") or cell.get("data") or str(cell)
                                        if out_txt:
                                            await _stream_update(
                                                "notebook_cell_output", 
                                                "info", 
                                                f"💬 [{task_key}] {out_txt}", 
                                                is_completed=is_final_task, 
                                                output=out_txt, 
                                                run_id=run_id
                                            )
                                            if is_final_task:
                                                logger.info(f"🛑 Found CELL OUTPUT in '{FINAL_TASK_KEY}'. Stopping.")
                                                return {"success": True, "run_id": run_id, "stream_stopped_early": True}

                            # CHECK 3: Logs (Standard Out)
                            if "logs" in data:
                                logs = data["logs"]
                                logs_key = f"{task_run_id}_logs"
                                if logs and logs_key not in seen_outputs:
                                    seen_outputs.add(logs_key)
                                    await _stream_update(
                                        "notebook_log", 
                                        "info", 
                                        f"📋 [{task_key}] Logs acquired", 
                                        is_completed=is_final_task, 
                                        log=logs, 
                                        run_id=run_id
                                    )
                                    if is_final_task:
                                        logger.info(f"🛑 Found LOGS in '{FINAL_TASK_KEY}'. Stopping.")
                                        return {"success": True, "run_id": run_id, "stream_stopped_early": True}
                                        
                        # CHECK 4: Error
                        if "error" in data:
                             err_msg = data["error"]
                             # FILTER: Ignore transient "No output" errors
                             if err_msg and IGNORE_ERROR_MSG not in err_msg:
                                 err_key = f"{task_run_id}_error"
                                 if err_key not in seen_outputs:
                                     seen_outputs.add(err_key)
                                     logger.warning(f"Task {task_key} Error: {err_msg}")
                                     await _stream_update("notebook_error", "error", f"❌ [{task_key}] Error: {err_msg}", is_completed=False)

                except Exception as e:
                    logger.warning(f"Error fetching task output: {e}")

            # Job Finished Check
            if life_cycle_state in ["TERMINATED", "SKIPPED", "INTERNAL_ERROR"]:
                result_state = state.get("result_state")
                success = (result_state == "SUCCESS")
                await _stream_update("job_completed", "success" if success else "error", f"Job Ended: {result_state}", is_completed=False, result_state=result_state)
                return {"success": success, "run_id": run_id, "result_state": result_state}
                
    except Exception as e:
        logger.error(f"Job Runner Error: {e}")
        await _stream_update("job_error", "error", f"❌ Error: {str(e)}", is_completed=False)
        return {"success": False, "error": str(e)}

async def trigger_job(
    job_id: int,
    context: str,
    websocket: WebSocket = None,
    original_query: str = None
) -> Dict[str, Any]:
    
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }

    try:
        # Log original query if provided
        if original_query:
            logger.info(f"📝 Original Query: {original_query[:100]}...")
        
        # Step 1: Trigger
        logger.info(f"🚀 Triggering Job {job_id}...")
        
        trigger_url = f"{DATABRICKS_HOST}/api/2.1/jobs/run-now"
        trigger_payload = {"job_id": job_id, "job_parameters": {"context": context}}
        
        trigger_response = await asyncio.to_thread(requests.post, trigger_url, headers=headers, json=trigger_payload, timeout=30)
        
        if trigger_response.status_code != 200:
            raise Exception(f"Job trigger failed: {trigger_response.text}")
        
        run_id = trigger_response.json()["run_id"]
        
        logger.info(f"✅ Job successfully triggered. Run ID: {run_id}")
        
        # Notify UI that job started (Fire and Forget)
        if websocket:
            await websocket.send_json({
                "step": "job_triggered",
                "status": "success",
                "message": f"✅ Access check job started (Run ID: {run_id})",
                "is_completed": False,
                "timestamp": time.time()
            })

        return {"success": True, "run_id": run_id, "status": "triggered"}

    except Exception as e:
        logger.error(f"Job Trigger Error: {e}")
        if websocket:
            await websocket.send_json({
                "step": "job_error",
                "status": "error",
                "message": f"❌ Error triggering job: {str(e)}",
                "is_completed": True,
                "timestamp": time.time()
            })
        return {"success": False, "error": str(e)}