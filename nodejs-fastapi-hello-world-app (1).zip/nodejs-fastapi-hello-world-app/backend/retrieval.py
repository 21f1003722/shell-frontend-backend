"""
Enhanced retrieval and generation module with robust response parsing and error handling.
"""

import logging
import asyncio
import json
from typing import Dict, Any, Optional, List
from fastapi import WebSocket

from backend.config import (
    orchestration_client,
    AZURE_OPENAI_DEPLOYMENT,
    QUERY_REPHRASER_MODEL,
    RETRIEVAL_MODEL,
    RESPONSE_GENERATOR_MODEL
)
from backend.utils import call_databricks_with_retry, diagnose_mlflow_error

logger = logging.getLogger("IT4IT_Retrieval")


class RetrievalError(Exception):
    """Custom exception for retrieval errors"""
    pass


class GenerationError(Exception):
    """Custom exception for generation errors"""
    pass


async def extract_domain_and_entities(query: str, websocket: WebSocket = None) -> Dict[str, Any]:
    """
    Extract domain name and IT4IT entities from the query.
    
    Args:
        query: User query string
        websocket: Optional WebSocket for streaming updates
        
    Returns:
        Dictionary with domain and entities
        
    Raises:
        Exception: If domain extraction fails critically
    """
    logger.info(f"Extracting domain and entities from: {query}")
    
    extraction_prompt = f"""Analyze this IT4IT query and extract:
1. Domain name (e.g., "Detect to Correct", "Request to Fulfill", "Requirement to Deploy",Strategy to Portfolio")
2. IT4IT entities mentioned (e.g., "Service Model", "Resource Utilization", "Incident", etc.)

Query: {query}

Respond in JSON format:
{{
    "domain": "domain name",
    "entities": ["entity1", "entity2", ...]
}}

Respond ONLY with valid JSON, no other text."""
    
    try:
        response = await asyncio.to_thread(
            orchestration_client.chat.completions.create,
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[{"role": "user", "content": extraction_prompt}],
            temperature=0,
            max_tokens=200
        )
        
        result_text = response.choices[0].message.content.strip()
        # Clean up markdown if present
        result_text = result_text.replace("```json", "").replace("```", "").strip()
        
        extraction = json.loads(result_text)
        
        logger.info(f"✅ Extracted - Domain: {extraction.get('domain')}, Entities: {extraction.get('entities')}")
        
        return {
            "domain": extraction.get("domain", "Unknown"),
            "entities": extraction.get("entities", [])
        }
        
    except Exception as e:
        logger.warning(f"Domain/entity extraction failed (non-critical): {e}")
        # Return defaults but don't fail - this is not critical
        return {
            "domain": "Unknown",
            "entities": []
        }


async def parse_retrieval_chunks(retrieved_content: Any) -> List[Dict[str, Any]]:
    """
    Parse retrieved content into structured chunks with robust error handling.
    
    Args:
        retrieved_content: Raw content from retrieval model (can be string, dict, or list)
        
    Returns:
        List of chunk dictionaries
    """
    logger.info(f"Parsing retrieval content, type: {type(retrieved_content)}")
    
    try:
        # Case 1: Already a list
        if isinstance(retrieved_content, list):
            logger.info("Content is already a list")
            return retrieved_content if retrieved_content else []
        
        # Case 2: Dictionary
        if isinstance(retrieved_content, dict):
            logger.info("Content is a dictionary")
            
            # Check for common data keys
            if 'data_array' in retrieved_content:
                logger.info("Found 'data_array' key in dict")
                data = retrieved_content['data_array']
                if isinstance(data, list):
                    return data
                elif isinstance(data, str):
                    try:
                        parsed = json.loads(data)
                        return parsed if isinstance(parsed, list) else [parsed]
                    except:
                        return [{"content": data, "source": "data_array"}]
            
            # Check for other common keys
            for key in ['results', 'documents', 'chunks', 'data', 'items']:
                if key in retrieved_content:
                    logger.info(f"Found '{key}' key in dict")
                    data = retrieved_content[key]
                    if isinstance(data, list):
                        return data
                    elif isinstance(data, str):
                        try:
                            parsed = json.loads(data)
                            return parsed if isinstance(parsed, list) else [parsed]
                        except:
                            return [{"content": data, "source": key}]
            
            # If no known keys, return the dict as a single chunk
            logger.info("No known keys found, returning dict as single chunk")
            return [retrieved_content]
        
        # Case 3: String content
        if isinstance(retrieved_content, str):
            logger.info(f"Content is a string, length: {len(retrieved_content)}")
            retrieved_str = retrieved_content.strip()
            
            # Try to parse as JSON
            if retrieved_str.startswith('[') or retrieved_str.startswith('{'):
                try:
                    logger.info("Attempting to parse string as JSON")
                    chunks = json.loads(retrieved_str)
                    if isinstance(chunks, dict):
                        logger.info("Parsed JSON is dict, converting to list")
                        return [chunks]
                    elif isinstance(chunks, list):
                        logger.info(f"Parsed JSON is list with {len(chunks)} items")
                        return chunks
                except json.JSONDecodeError as e:
                    logger.warning(f"JSON parsing failed: {e}")
                    # Fall through to text parsing
            
            # Parse as text with line breaks
            logger.info("Parsing as plain text")
            lines = retrieved_str.split('\n')
            chunks = []
            current_chunk = {}
            
            for line in lines:
                line = line.strip()
                if not line:
                    if current_chunk:
                        chunks.append(current_chunk)
                        current_chunk = {}
                    continue
                
                # Try to parse key-value pairs
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip().lower().replace(' ', '_')
                    value = parts[1].strip()
                    current_chunk[key] = value
                else:
                    if 'content' not in current_chunk:
                        current_chunk['content'] = line
                    else:
                        current_chunk['content'] += ' ' + line
            
            if current_chunk:
                chunks.append(current_chunk)
            
            # If still no structured chunks, return as single chunk
            if not chunks:
                logger.info("No structured data found, returning raw content")
                return [{
                    "content": retrieved_str[:1000],  # Limit to first 1000 chars
                    "source": "raw_retrieval",
                    "full_length": len(retrieved_str)
                }]
            
            logger.info(f"Parsed {len(chunks)} chunks from text")
            return chunks
        
        # Case 4: Other types - convert to string
        logger.warning(f"Unexpected type: {type(retrieved_content)}, converting to string")
        return [{
            "content": str(retrieved_content)[:1000],
            "source": "converted",
            "original_type": str(type(retrieved_content))
        }]
        
    except Exception as e:
        logger.error(f"Error parsing retrieval chunks: {e}")
        # Return error info as a chunk
        return [{
            "error": "Failed to parse retrieval response",
            "error_details": str(e),
            "content": str(retrieved_content)[:500] if retrieved_content else "No content"
        }]


async def retrieve_and_generate_enhanced(
    query: str, 
    websocket: WebSocket = None
) -> Dict[str, Any]:
    """
    Enhanced retrieval and generation with robust error handling and response parsing.
    
    Args:
        query: User query string
        websocket: Optional WebSocket for streaming updates
        
    Returns:
        Dictionary containing response, context, chunks, and metadata
        Sets retrieval_success=False or generation_success=False on errors
    """
    
    async def _stream_update(step: str, status: str, message: str, **kwargs):
        """Helper to stream updates if websocket is available"""
        if websocket:
            try:
                update = {
                    "step": step,
                    "status": status,
                    "message": message,
                    "timestamp": asyncio.get_event_loop().time(),
                    **kwargs
                }
                await websocket.send_json(update)
                logger.info(f"[{step}] {status} - {message}")
            except Exception as e:
                logger.error(f"Failed to stream update: {e}")
    
    # ============================================================================
    # STEP 1: DOMAIN & ENTITY EXTRACTION
    # ============================================================================
    logger.info("=" * 80)
    logger.info("STEP 1: EXTRACTING DOMAIN AND ENTITIES")
    logger.info("=" * 80)
    
    # await _stream_update(
    #     "step_1_extraction",
    #     "started",
    #     "🔍 Analyzing query to extract domain and entities...",
    #     is_compeleted=False, 
    #     reasoning="Identifying IT4IT domain and relevant entities from the query"
    # )
    
    domain_entities = await extract_domain_and_entities(query, websocket)
    
    await _stream_update(
        "step_1_extraction",
        "completed",
        f"✅ Domain identified: {domain_entities['domain']}",
        is_compeleted=False,
        domain=domain_entities['domain'],
        entities=domain_entities['entities'],
        reasoning=f"Query belongs to '{domain_entities['domain']}' domain with entities: {', '.join(domain_entities['entities']) if domain_entities['entities'] else 'None'}"
    )
    
    # ============================================================================
    # STEP 2: QUERY REPHRASING
    # ============================================================================
    logger.info("=" * 80)
    logger.info("STEP 2: QUERY REPHRASING")
    logger.info("=" * 80)
    
    await _stream_update(
        "step_2_rephrasing",
        "started",
        "🔄Calling Rephraser Agent for query optimization...",
        is_compeleted=False,
        original_query=query,
        reasoning="Rephrasing query to improve vector search accuracy"
    )
    
    try:
        rephrased_query = await asyncio.to_thread(
            call_databricks_with_retry,
            QUERY_REPHRASER_MODEL,
            query,
            2,  # max_retries
            30  # timeout
        )
        
        # Use rephrased query if valid, otherwise use original
        if rephrased_query and len(rephrased_query.strip()) > 3:
            search_query = rephrased_query.strip()
            logger.info(f"✅ Query rephrased successfully")
            
            # await _stream_update(
            #     "step_2_rephrasing",
            #     "completed",
            #     "✅ Query optimized for search",
            #     original_query=query,
            #     is_compeleted=False, 
            #     rephrased_query=search_query,
            #     domain=domain_entities['domain'],
            #     entities=domain_entities['entities'],
            #     reasoning=f"Query reformulated for better retrieval in {domain_entities['domain']} domain"
            # )
        else:
            search_query = query
            logger.warning("⚠️ Rephrasing returned empty, using original query")
            
            await _stream_update(
                "step_2_rephrasing",
                "warning",
                "⚠️ Using original query",
                is_compeleted=False,
                original_query=query,
                rephrased_query=query,
                domain=domain_entities['domain'],
                entities=domain_entities['entities'],
                reasoning="Rephrasing returned empty result, proceeding with original query"
            )
            
    except Exception as e:
        error_msg = str(e)
        logger.warning(f"Rephrasing failed (non-critical): {e}, using original query")
        
        search_query = query
        
        await _stream_update(
            "step_2_rephrasing",
            "warning",
            "⚠️ Rephrasing failed, using original query",
            original_query=query,
            rephrased_query=query,
            is_compeleted=False,
            domain=domain_entities['domain'],
            entities=domain_entities['entities'],
            error=error_msg,
            reasoning=f"Query optimization encountered an error: {error_msg[:100]}"
        )
    
    # ============================================================================
    # STEP 3: RETRIEVAL (CRITICAL - MUST SUCCEED)
    # ============================================================================
    logger.info("=" * 80)
    logger.info("STEP 3: VECTOR DATABASE RETRIEVAL")
    logger.info("=" * 80)
    
    await _stream_update(
        "step_3_retrieval",
        "started",
        "🔎 Calling Retrieval Agent :Querying vector database for relevant documents...",
        search_query=search_query,
        is_compeleted=False,
        reasoning=f"Searching indexed documents in {domain_entities['domain']} domain"
    )
    
    try:
        logger.info(f"Calling retrieval model: {RETRIEVAL_MODEL}")
        retrieved_content = await asyncio.to_thread(
            call_databricks_with_retry,
            RETRIEVAL_MODEL,
            search_query,
            2,  # max_retries
            45  # timeout
        )
        
        logger.info(f"Raw retrieval response type: {type(retrieved_content)}")
        logger.info(f"Raw retrieval response preview: {str(retrieved_content)[:500]}")
        
        # Check if response is valid
        if not retrieved_content:
            logger.error("❌ Retrieved content is None or empty - RETRIEVAL FAILED")
            
            await _stream_update(
                "step_3_retrieval",
                "failed",
                "❌ No response from retrieval model",
                is_compeleted=False,
                reasoning="Vector search returned empty response",
                chunks=[],
                context_length=0
            )
            
            return {
                "response": "",
                "query": query,
                "rephrased_query": search_query,
                "domain": domain_entities['domain'],
                "entities": domain_entities['entities'],
                "context": "",
                "chunks": [],
                "reasoning": "RETRIEVAL FAILED: Retrieval model returned empty response",
                "no_context": True,
                "retrieval_success": False,
                "generation_success": False
            }
        
        # Check for error strings BEFORE parsing chunks
        content_str = str(retrieved_content).lower()
        if any(error_pattern in content_str for error_pattern in [
            "failed to retrieve",
            "error retrieving",
            "retrieval failed",
            "no documents found",
            "data_array",  # Common error key
            "failed_to_retrieve_documents"
        ]):
            logger.error(f"❌ Retrieval returned error message: {str(retrieved_content)[:200]}")
            
            await _stream_update(
                "step_3_retrieval",
                "failed",
                f"❌ Retrieval error detected",
                is_compeleted=False,
                reasoning="Vector search returned an error message instead of documents",
                chunks=[],
                context_length=0,
                error_message=str(retrieved_content)[:500]
            )
            
            return {
                "response": "",
                "query": query,
                "rephrased_query": search_query,
                "domain": domain_entities['domain'],
                "entities": domain_entities['entities'],
                "context": "",
                "chunks": [],
                "reasoning": f"RETRIEVAL FAILED: {str(retrieved_content)[:200]}",
                "no_context": True,
                "retrieval_success": False,
                "generation_success": False,
                "error_message": str(retrieved_content)
            }
        
        # Parse retrieval chunks with robust error handling
        chunks = await parse_retrieval_chunks(retrieved_content)
        
        # Check if chunks contain error information
        if chunks and len(chunks) > 0:
            first_chunk = chunks[0]
            if "error" in first_chunk or "failed_to_retrieve_documents" in first_chunk:
                error_detail = first_chunk.get("error", first_chunk.get("failed_to_retrieve_documents", "Unknown error"))
                logger.error(f"❌ Retrieval returned error: {error_detail}")
                
                await _stream_update(
                    "step_3_retrieval",
                    "failed",
                    f"❌ Retrieval error: {error_detail}",
                    is_compeleted=False,
                    reasoning="Vector search encountered an error",
                    chunks=[],
                    context_length=0,
                    error_details=first_chunk
                )
                
                return {
                    "response": "",
                    "query": query,
                    "rephrased_query": search_query,
                    "domain": domain_entities['domain'],
                    "entities": domain_entities['entities'],
                    "context": "",
                    "chunks": [],
                    "reasoning": f"RETRIEVAL FAILED: {error_detail}",
                    "no_context": True,
                    "retrieval_success": False,
                    "generation_success": False,
                    "error_details": first_chunk
                }
        
        # Check if we have valid chunks - STOP EXECUTION IF NONE FOUND
        if not chunks or len(chunks) == 0:
            logger.error("❌ NO CHUNKS FOUND - EXECUTION STOPPED")
            
            await _stream_update(
                "step_3_retrieval",
                "failed",
                "❌ No chunks found - execution stopped",
                is_compeleted=False,
                reasoning="Vector search returned no document chunks. Execution halted.",
                chunks=[],
                context_length=0
            )
            
            return {
                "response": "No relevant documents found in the knowledge base for your query.",
                "query": query,
                "rephrased_query": search_query,
                "domain": domain_entities['domain'],
                "entities": domain_entities['entities'],
                "context": "",
                "chunks": [],
                "reasoning": "EXECUTION STOPPED: No chunks retrieved from knowledge base",
                "no_context": True,
                "retrieval_success": False,
                "generation_success": False,
                "error": "NO_CHUNKS_FOUND"
            }
        
        # Check if chunks have minimal content
        context_str = str(retrieved_content)
        if len(context_str.strip()) < 10:
            logger.error("❌ NO MEANINGFUL CONTENT IN CHUNKS - EXECUTION STOPPED")
            
            await _stream_update(
                "step_3_retrieval",
                "failed",
                "❌ No meaningful content found - execution stopped",
                is_compeleted=False,
                reasoning="Retrieved chunks contain insufficient content. Execution halted.",
                chunks=chunks,
                context_length=len(context_str)
            )
            
            return {
                "response": "No relevant content found in the knowledge base for your query.",
                "query": query,
                "rephrased_query": search_query,
                "domain": domain_entities['domain'],
                "entities": domain_entities['entities'],
                "context": context_str,
                "chunks": chunks,
                "reasoning": "EXECUTION STOPPED: Retrieved content is too minimal",
                "no_context": True,
                "retrieval_success": False,
                "generation_success": False,
                "error": "INSUFFICIENT_CONTENT"
            }
        
        logger.info(f"✅ Retrieved {len(context_str)} characters in {len(chunks)} chunks")
        
        await _stream_update(
            "step_3_retrieval",
            "completed",
            "✅ Retrieved relevant document chunks",
            is_compeleted=False,
            context_length=len(context_str),
            chunks=chunks,
            chunk_count=len(chunks),
            context_preview=context_str[:300] + "..." if len(context_str) > 300 else context_str,
            reasoning=f"Found {len(chunks)} relevant document chunks totaling {len(context_str)} characters"
        )
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ RETRIEVAL FAILED: {e}", exc_info=True)
        
        diagnosis = diagnose_mlflow_error(error_msg)
        
        await _stream_update(
            "step_3_retrieval",
            "failed",
            f"❌ Retrieval error: {error_msg[:100]}",
            is_compeleted=False,
            error=error_msg,
            reasoning="Vector search encountered a critical error",
            mlflow_diagnosis=diagnosis if diagnosis["is_mlflow_error"] else None
        )
        
        return {
            "response": "",
            "query": query,
            "rephrased_query": search_query,
            "domain": domain_entities['domain'],
            "entities": domain_entities['entities'],
            "context": "",
            "chunks": [],
            "reasoning": f"RETRIEVAL FAILED: {error_msg}",
            "no_context": True,
            "retrieval_success": False,
            "generation_success": False,
            "mlflow_error": diagnosis["is_mlflow_error"],
            "error_diagnosis": diagnosis if diagnosis["is_mlflow_error"] else None
        }
    
    # ============================================================================
    # STEP 4: RESPONSE GENERATION (CRITICAL - MUST SUCCEED)
    # ============================================================================
    logger.info("=" * 80)
    logger.info("STEP 4: RESPONSE GENERATION")
    logger.info("=" * 80)
    
    context_str = str(retrieved_content)
    
    await _stream_update(
        "step_4_generation",
        "started",
        "🤖 Generating comprehensive response from retrieved context...",
        is_compeleted=False,
        context_size=len(context_str),
        chunk_count=len(chunks),
        reasoning="Using AI model to synthesize answer from the found documents"
    )
    
    # Format input for generation
    formatted_input = f"""Context from knowledge base:
{context_str}

User Question: {query}

Provide a comprehensive answer based on the context above."""
    
    try:
        answer = await asyncio.to_thread(
            call_databricks_with_retry,
            RESPONSE_GENERATOR_MODEL,
            formatted_input,
            2,  # max_retries
            60  # timeout
        )
        
        if not answer or len(str(answer).strip()) < 10:
            logger.error("❌ Generated response was too short - GENERATION FAILED")
            
            await _stream_update(
                "step_4_generation",
                "failed",
                "❌ Generated response was too short",
                is_compeleted=False,
                reasoning="Response generation completed but result was minimal"
            )
            
            return {
                "response": "",
                "query": query,
                "rephrased_query": search_query,
                "domain": domain_entities['domain'],
                "entities": domain_entities['entities'],
                "context": context_str,
                "chunks": chunks,
                "reasoning": "GENERATION FAILED: Response generation returned empty or minimal result",
                "retrieval_success": True,
                "generation_success": False
            }
        
        logger.info(f"✅ Generated response: {len(answer)} characters")
        
        # await _stream_update(
        #     "step_4_generation",
        #     "completed",
        #     f"✅ Generated {len(answer)} character response",
        #     is_compeleted=False,
        #     response_length=len(answer),
        #     response_preview=str(answer)[:200] + "..." if len(str(answer)) > 200 else str(answer),
        #     reasoning="Successfully synthesized answer from retrieved context"
        # )
        
        return {
            "response": str(answer),
            "query": query,
            "rephrased_query": search_query,
            "domain": domain_entities['domain'],
            "entities": domain_entities['entities'],
            "context": context_str,
            "chunks": chunks,
            "chunk_count": len(chunks),
            "reasoning": f"Successfully retrieved {len(chunks)} chunks ({len(context_str)} chars) and generated response",
            "no_context": False,
            "retrieval_success": True,
            "generation_success": True
        }
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ GENERATION FAILED: {e}", exc_info=True)
        
        diagnosis = diagnose_mlflow_error(error_msg)
        
        await _stream_update(
            "step_4_generation",
            "failed",
            f"❌ Generation error: {error_msg[:100]}",
            is_compeleted=False,
            error=error_msg,
            reasoning="Response generation encountered a critical error",
            mlflow_diagnosis=diagnosis if diagnosis["is_mlflow_error"] else None
        )
        
        return {
            "response": "",
            "query": query,
            "rephrased_query": search_query,
            "domain": domain_entities['domain'],
            "entities": domain_entities['entities'],
            "context": context_str,
            "chunks": chunks,
            "reasoning": f"GENERATION FAILED: {error_msg}",
            "retrieval_success": True,
            "generation_success": False,
            "mlflow_error": diagnosis["is_mlflow_error"],
            "error_diagnosis": diagnosis if diagnosis["is_mlflow_error"] else None
        }
